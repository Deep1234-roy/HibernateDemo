package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		Car car = new Car();
		car.setCar_name("Auto Mobile");
		EconomicalCar ecoCar = new EconomicalCar();
		ecoCar.setCar_name("BMW Auto");
		ecoCar.setCar_price(7.9f);
		ecoCar.setCar_milage(88.0f);
		LuxuriousCar luxCar = new LuxuriousCar();
		luxCar.setCar_name("Auto");
		luxCar.setEngine_capacity(8790);
		luxCar.setCar_features("Partially Loaded");
		session.save(car);
		session.save(ecoCar);
		session.save(luxCar);
		trans.commit();
		System.out.println("Table created And data added");

	}

}
