package com.pojo;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("LuxuriousCar")
public class LuxuriousCar extends Car {
	private int engine_capacity;
	private String car_features;
	public int getEngine_capacity() {
	return engine_capacity;
	}
	public void setEngine_capacity(int engine_capacity) {
	this.engine_capacity = engine_capacity;
	}
	public String getCar_features() {
	return car_features;
	}
	public void setCar_features(String car_features) {
	this.car_features = car_features;
	}
}
