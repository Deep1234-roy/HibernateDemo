package com.module;

public class BookingDetails {
	private int book_id;
	private String book_date;
	private String cust_name;
	private long cust_phone;
	private int room_number;
	private int DayToHireFor;
	private double room_fare;
	private double bill;
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_date() {
		return book_date;
	}
	public void setBook_date(String book_date) {
		this.book_date = book_date;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public long getCust_phone() {
		return cust_phone;
	}
	public void setCust_phone(long cust_phone) {
		this.cust_phone = cust_phone;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public int getDayToHireFor() {
		return DayToHireFor;
	}
	public void setDayToHireFor(int dayToHireFor) {
		DayToHireFor = dayToHireFor;
	}
	public double getRoom_fare() {
		return room_fare;
	}
	public void setRoom_fare(double room_fare) {
		this.room_fare = room_fare;
	}
	public double getBill() {
		return bill;
	}
	public void setBill(double bill) {
		this.bill = bill;
	}
	
	
	
	
}
