package com.module;

public class Room {
	private int room_number;
	private String room_type;
	private double room_fare;
	private String room_ac;
	private String room_avbl;
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public double getRoom_fare() {
		return room_fare;
	}
	public void setRoom_fare(double room_fare) {
		this.room_fare = room_fare;
	}
	public String getRoom_ac() {
		return room_ac;
	}
	public void setRoom_ac(String room_ac) {
		this.room_ac = room_ac;
	}
	public String getRoom_avbl() {
		return room_avbl;
	}
	public void setRoom_avbl(String room_avbl) {
		this.room_avbl = room_avbl;
	}
	
}
