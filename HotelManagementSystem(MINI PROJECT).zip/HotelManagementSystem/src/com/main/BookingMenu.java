package com.main;

import java.util.Scanner;

import com.controller.BookingController;
import com.controller.CustomerController;

public class BookingMenu {
	public BookingMenu() {
		System.out.println("***************BOOKING OPERATIONS***************");
		System.out.println("     1.           Add Booking \n     2.           Update Booking Information \n     3.           Delete Booking Information \n     4.           Display All Booking Information \n     5.           Display Individiual Booking Information \n     0.           Exit");
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter your Operation : - ");
		int ch  = sc.nextInt();
		switch(ch) {
		case 1:
			BookingController book = new BookingController();
			book.addBooking();
			break;
		case 2:
			BookingController book1 = new BookingController();
			book1.updateBookingDetails();
			break;
		case 3:
			BookingController book2 = new BookingController();
			book2.deleteBookingDetails();
			break;
		case 4:
			BookingController book3 = new BookingController();
			book3.getAllBookingDetails();
			break;
		case 5:
			BookingController book4 = new BookingController();
			book4.getSpecificBookingDetails();
			break;
		case 0:
			System.out.println("Thanks for Closing the Booking Operation Menu!!!!");
			System.out.println("----------------------------------------------------");
			AdminMenu obj = new AdminMenu();
			break;
		default:
			System.out.println("Please Choose Valid Booking Operations!!!");
			BookingMenu obj1 = new BookingMenu();
			
		}
	}
}
