package com.main;

import java.util.Scanner;

import com.controller.RoomController;

public class RoomMenu {
	public RoomMenu() {
		System.out.println("*****************ROOM OPERATION*****************");
		System.out.println("     1.           ADD Room \n     2.           UPDATE Room Details \n     3.           DELETE Room Record \n     4.           DISPLAY All Room \n     5.           DISPLAY All Room Information according to it's Type \n     0.           Exit");
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter your Room Operation : - ");
		int ch  = sc.nextInt();
		switch(ch) {
		case 1:
			RoomController rom1 = new RoomController();
			rom1.AddRoom();
			break;
		case 2:
			RoomController rom2 = new RoomController();
			rom2.updateRoom();
			break;
		case 3:
			RoomController rom3 = new RoomController();
			rom3.deleteRooms();
			break;
		case 4:
			RoomController rom4 = new RoomController();
			rom4.getAllRoomDetails();
			break;
		case 5:
			RoomController rom5 = new RoomController();
			rom5.getSpecifiedTypesRoom();
			break;
		case 0:
			System.out.println("Thanks for Closing Room Operation Menu!!!!");
			System.out.println("----------------------------------------");
			AdminMenu adm = new AdminMenu();
			break;
		}
	}
}
