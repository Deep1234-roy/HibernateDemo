package com.main;

import java.util.Scanner;

import com.controller.CustomerController;

public class CustomerMenu {
	public CustomerMenu() {
		System.out.println("***************CUSTOMER OPERATIONS***************");
		System.out.println("     1.           Add Customer Information \n     2.           Update Customer Information \n     3.           Delete Customer Information \n     4.           Display All Customer Information \n     5.           Display Individiual Customer's Information \n     0.           Exit");
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter your Operation : - ");
		int ch  = sc.nextInt();
		switch(ch) {
		case 1:
			CustomerController cust = new CustomerController();
			cust.addCustomer();
			break;
		case 2:
			CustomerController cust1 = new CustomerController();
			cust1.updateCustomers();
			break;
		case 3:
			CustomerController cust2 = new CustomerController();
			cust2.deleteCustomers();
			break;
		case 4:
			CustomerController cust3 = new CustomerController();
			cust3.getCustomer();
			break;
		case 5:
			CustomerController cust4 = new CustomerController();
			cust4.getIndividualCustomer();
			break;
		case 0:
			System.out.println("Thanks for Closing the Customer Operation Menu!!!!");
			System.out.println("----------------------------------------------------");
			AdminMenu obj = new AdminMenu();
			break;
		}
	}
}
