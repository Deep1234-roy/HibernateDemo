package com.main;

import java.util.Scanner;

public class AdminMenu {
	public AdminMenu() {
		System.out.println("-------------------ADMIN OPERATIONS-------------------");
		System.out.println("     1.           Customer Operation \n     2.           Room Operation \n     3.           Booking Operation \n     0.           Exit");
		System.out.println("------------------------------------------------------");
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter your Operation : - ");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("You have Selected for Customer Operation!!!");
			CustomerMenu cst = new CustomerMenu();
			break;
		case 2:
			System.out.println("You have Selected For Room Operation!!!");
			RoomMenu rom = new RoomMenu();
			break;
		case 3:
			System.out.println("You have Selected For Booking Operation!!!");
			BookingMenu book = new BookingMenu();
			break;
		case 0:
			System.out.println("Thanks for Closing our Application!!!");
			System.exit(0);
			break;
		}
	}
}
