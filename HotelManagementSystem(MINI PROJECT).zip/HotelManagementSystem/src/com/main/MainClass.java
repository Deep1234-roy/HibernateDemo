package com.main;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("********************HOTEL MANAGEMENT SYSTEM********************");
		AdminMenu adm = new AdminMenu();

	}

}
