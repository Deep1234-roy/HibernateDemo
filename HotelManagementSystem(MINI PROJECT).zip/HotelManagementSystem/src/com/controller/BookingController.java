package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.dao.ConfigurationDao;
import com.main.BookingMenu;
import com.main.CustomerMenu;
import com.module.BookingDetails;
import com.module.Customer;

public class BookingController {
	static Configuration conf = ConfigurationDao.getCustomConfig();
	static BookingDetails bd = new BookingDetails();
	
	//Add booking
	public static void addBooking() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		System.out.print("Enter the Booking Date : - ");
		String book_date = input.next();
		System.out.print("Enter the Customer Name : - ");
		String cust_name = input.next();
		System.out.print("Enter the Customer Phone Number : - ");
		long cust_phone = input.nextLong();
		System.out.print("Enter the Room Number : - ");
		int room_number= input.nextInt();
		System.out.print("How many Days you want for Booking ? - ");
		int DayToHireFor = input.nextInt();
		System.out.print("Enter the Room Charge : - ");
		double room_fare = input.nextDouble();
		bd.setBook_date(book_date);
		bd.setCust_name(cust_name);
		bd.setCust_phone(cust_phone);
		bd.setRoom_number(room_number);
		bd.setDayToHireFor(DayToHireFor);
		bd.setRoom_fare(room_fare);
		bd.setBill(room_fare * DayToHireFor);
		session.save(bd);
		tran.commit();
		session.close();
		System.out.print("Do You Wish to Add More Booking ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			addBooking();
		}else {
			System.out.println("Thanks for Adding the Booking Information!!!");
			BookingMenu csm = new BookingMenu();
		}
		System.out.println("Booking Added Successfully");
	}
	
	//Update Booking Information
	public static void updateBookingDetails() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("update BookingDetails set book_date=:d,cust_name=:g,cust_phone=:a,room_number=:h,DayToHireFor=:p,room_fare=:e,bill=:l where book_id=:i");
		System.out.print("Enter the Booking ID for which you want to Update : - ");
		int book_id = input.nextInt();
		System.out.print("Enter the New Booking Date : - ");
		String book_date = input.next();
		System.out.print("Enter the New Customer Name : - ");
		String cust_name = input.next();
		System.out.print("Enter the New Phone Number of Customer : - ");
		long cust_phone = input.nextLong();
		System.out.print("Enter the New Room Number : - ");
		int room_number = input.nextInt();
		System.out.print("How many Days you want for Booking ? - ");
		int DayToHireFor = input.nextInt();
		System.out.print("Enter the New Room Charge : - ");
		double room_fare = input.nextDouble();
		double bill = room_fare * DayToHireFor;
		qr.setParameter("d", book_date);
		qr.setParameter("g", cust_name);
		qr.setParameter("a", cust_phone);
		qr.setParameter("h", room_number);
		qr.setParameter("p", DayToHireFor);
		qr.setParameter("e", room_fare);
		qr.setParameter("i", book_id);
		qr.setParameter("l", bill);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		System.out.println("Booking Records Updated Successfully!!!");
		tran.commit();
		System.out.print("Do You Wish to Update More Booking Details ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			updateBookingDetails();
		}else {
			System.out.println("Thanks for Updating the Booking Details Information!!!");
			BookingMenu csm = new BookingMenu();
		}
	}
	
	//Delete Booking Information
	public static void deleteBookingDetails() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("delete from BookingDetails where book_id=:i");
		System.out.print("Enter the Booking ID for which you want to Delete : - ");
		int book_id = input.nextInt();
		qr.setParameter("i", book_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		System.out.println("Booking Records Deleted Successfully!!!");
		tran.commit();
		System.out.print("Do You Wish to Delete More Booking Records ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			deleteBookingDetails();
		}else {
			System.out.println("Thanks for Deleting the Booking Details Information!!!");
			BookingMenu csm = new BookingMenu();
		}
	}
	
	//Get all Booking Details Information
	public static void getAllBookingDetails() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		TypedQuery qr = session.createQuery("from BookingDetails"); 
		List<BookingDetails> bdetails = qr.getResultList();
		Iterator<BookingDetails> itr = bdetails.iterator();
		System.out.println("************************************************************************Display Booking Details**********************************************************************************************");
		while(itr.hasNext()) {
			BookingDetails cust = itr.next();
			System.out.println("Booking ID = " + cust.getBook_id() + " , " 
					+ "Booking Date = "+ cust.getBook_date() + " , " + "Customer Name = " + cust.getCust_name()
					+ " , " + "Customer Phone Number = " + cust.getCust_phone() + " , "
					+ " Room Number = "+ cust.getRoom_number() + " , " + "DayToHireFor = " + cust.getDayToHireFor()
					+ " , " + "Room Charge = " + cust.getRoom_fare() + " , " + "Total Bill = " + cust.getBill());
		}
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		BookingMenu csm = new BookingMenu();
	}
	
	//Display Individual Booking Information by providing Booking ID
	public static void getSpecificBookingDetails() {
		Scanner input = new Scanner(System.in);
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Query query = session.createQuery("FROM BookingDetails B WHERE B.book_id = :i");
		System.out.print("Enter the Booking ID : - ");
		int book_id = input.nextInt();
		query.setParameter("i", book_id);
		List<BookingDetails> results = query.list();
		Iterator<BookingDetails> itr = results.iterator();
		System.out.println("************************************************************************Display Booking Details**********************************************************************************************");
		while(itr.hasNext()) {
			BookingDetails cust = itr.next();
			System.out.println("Booking ID = " + cust.getBook_id() + " , " 
					+ "Booking Date = "+ cust.getBook_date() + " , " + "Customer Name = " + cust.getCust_name()
					+ " , " + "Customer Phone Number = " + cust.getCust_phone() + " , "
					+ " Room Number = "+ cust.getRoom_number() + " , " + "DayToHireFor = " + cust.getDayToHireFor()
					+ " , " + "Room Charge = " + cust.getRoom_fare() + " , " + "Total Bill = " + cust.getBill());
		}
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.print("Do You Wish to See More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			getSpecificBookingDetails();
		}else {
			System.out.println("Thanks for Displaying the Individual Booking Information!!!");
			BookingMenu csm = new BookingMenu();
		}
	}
	
}
