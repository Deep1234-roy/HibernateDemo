package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.dao.ConfigurationDao;
import com.main.CustomerMenu;
import com.main.RoomMenu;
import com.module.Customer;
import com.module.Room;

public class RoomController {
	static Configuration conf = ConfigurationDao.getCustomConfig();
	static Room rom = new Room();
	
	//Add Room
	public static void AddRoom() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		System.out.print("Enter the Room Type : - ");
		String room_type = input.next();
		System.out.print("Enter the Room Charge : - ");
		double room_fare = input.nextDouble();
		System.out.print("Is AC Available in Room ? - ");
		String room_ac = input.next();
		System.out.print("Is Room Availble ? - ");
		String room_avbl = input.next();
		rom.setRoom_type(room_type);
		rom.setRoom_fare(room_fare);
		rom.setRoom_ac(room_ac);
		rom.setRoom_avbl(room_avbl);
		session.save(rom);
		tran.commit();
		session.close();
		System.out.print("Do You Wish to Add More Rooms ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			AddRoom();
		}else {
			System.out.println("Thanks for Adding the Rooms!!!");
			System.out.println("------------------------------------");
			RoomMenu csm = new RoomMenu();
		}
		System.out.println("Rooms Added Successfully");
	}
	
	//Update Room
	public static void updateRoom() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("update Room set room_type=:n,room_fare=:f,room_ac=:a,room_avbl=:v where room_number=:i");
		System.out.print("Enter the Room Number for which you want to Update : - ");
		int room_number = input.nextInt();
		System.out.print("Enter the New Room Type : - ");
		String room_type = input.next();
		System.out.print("Enter the New Room Charge : - ");
		double room_fare = input.nextDouble();
		System.out.print("Is AC Available in Room ? - ");
		String room_ac = input.next();
		System.out.print("Is Room Availble ? - ");
		String room_avbl = input.next();
		qr.setParameter("n", room_type);
		qr.setParameter("f", room_fare);
		qr.setParameter("a", room_ac);
		qr.setParameter("v", room_avbl);
		qr.setParameter("i", room_number);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		System.out.println("Room Records Updated Successfully!!!");
		tran.commit();
		System.out.print("Do You Wish to Update More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			updateRoom();
		}else {
			System.out.println("Thanks for Updating the Room Information!!!");
			System.out.println("-----------------------------------------------");
			RoomMenu csm = new RoomMenu();
		}
	}
	
	//Delete Room
	public static void deleteRooms() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("delete from Room where room_number=:i");
		System.out.print("Enter the Room Number for Delete : - ");
		int room_number = input.nextInt();
		qr.setParameter("i", room_number);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		System.out.println("Room Records Deleted Successfully!!!");
		tran.commit();
		System.out.print("Do You Wish to Delete More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			deleteRooms();
		}else {
			System.out.println("Thanks for Deleting the Room Information!!!");
			RoomMenu csm = new RoomMenu();
		}
	}
	
	//Get all Room Details
	public static void getAllRoomDetails() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		TypedQuery qr = session.createQuery("from Room"); 
		List<Room> rooms = qr.getResultList();
		Iterator<Room> itr = rooms.iterator();
		System.out.println("************************************************************************Display Room Details**********************************************************************************************");
		while(itr.hasNext()) {
			Room room = itr.next();
			System.out.println("Room Number = " + room.getRoom_number() + " , " 
					+ "Room Type = "+ room.getRoom_type() + " , " + "Room Charge = " + room.getRoom_fare() + " , " + "AC Available = " + room.getRoom_ac() + " , "
					+ " Room Availble = "+ room.getRoom_avbl());
		}
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		RoomMenu csm = new RoomMenu();
	}
	
	//Get all specified types of Rooms
	public static void getSpecifiedTypesRoom() {
		Scanner input = new Scanner(System.in);
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Query query = session.createQuery("FROM Room R WHERE R.room_type = :i");
		System.out.print("Enter the Room Type for Display all it's Information : - ");
		String room_type = input.next();
		query.setParameter("i", room_type);
		List<Room> results = query.list();
		Iterator<Room> itr = results.iterator();
		System.out.println("************************************************************************Display Room Details**********************************************************************************************");
		while(itr.hasNext()) {
			Room rom = itr.next();
			System.out.println("Room Number = " + rom.getRoom_number() + " , " 
					+ "Room Type = "+ rom.getRoom_type() + " , " + "Room Charge = " + rom.getRoom_fare() + " , " + "AC Available = " + rom.getRoom_ac() + " , "
					+ " Room Availbale = "+ rom.getRoom_avbl());
		}
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.print("Do You Wish to See More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			getSpecifiedTypesRoom();
		}else {
			System.out.println("Thanks for Displaying the Individual Room Information!!!");
			RoomMenu csm = new RoomMenu();
		}
	}
}
