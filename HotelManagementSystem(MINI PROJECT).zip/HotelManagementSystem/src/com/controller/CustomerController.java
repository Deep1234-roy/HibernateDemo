package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.dao.ConfigurationDao;
import com.main.CustomerMenu;
import com.module.Customer;

public class CustomerController {
	static Configuration conf = ConfigurationDao.getCustomConfig();
	static Customer cust = new Customer();

	//Add Customer
	public static void addCustomer() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		System.out.print("Enter the Name of Customer : - ");
		String cust_name = input.next();
		System.out.print("Enter the Gender of Customer : - ");
		String cust_gender = input.next();
		System.out.print("Enter the Age of Customer : - ");
		int cust_age = input.nextInt();
		System.out.print("Enter the Address of Customer : - ");
		String cust_address = input.next();
		System.out.print("Enter the Phone No of Customer : - ");
		long cust_phone = input.nextLong();
		System.out.print("Enter the Email of Customer : - ");
		String cust_email = input.next();
		cust.setCust_name(cust_name);
		cust.setCust_gender(cust_gender);
		cust.setCust_age(cust_age);
		cust.setCust_address(cust_address);
		cust.setCust_phone(cust_phone);
		cust.setCust_email(cust_email);
		session.save(cust);
		tran.commit();
		session.close();
		System.out.print("Do You Wish to Add More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			addCustomer();
		}else {
			System.out.println("Thanks for Adding the Customers!!!");
			CustomerMenu csm = new CustomerMenu();
		}
		System.out.println("Customer Added Successfully");
	}
	
	//Update Customer
	public static void updateCustomers() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("update Customer set cust_name=:n,cust_gender=:g,cust_age=:a,cust_address=:h,cust_phone=:p,cust_email=:e where cust_id=:i");
		System.out.print("Enter the ID of Customer : - ");
		int cust_id = input.nextInt();
		System.out.print("Enter the Name of Customer : - ");
		String cust_name = input.next();
		System.out.print("Enter the Gender of Customer : - ");
		String cust_gender = input.next();
		System.out.print("Enter the Age of Customer : - ");
		int cust_age = input.nextInt();
		System.out.print("Enter the Address of Customer : - ");
		String cust_address = input.next();
		System.out.print("Enter the Phone No of Customer : - ");
		long cust_phone = input.nextLong();
		System.out.print("Enter the Email of Customer : - ");
		String cust_email = input.next();
		qr.setParameter("n", cust_name);
		qr.setParameter("i", cust_id);
		qr.setParameter("g", cust_gender);
		qr.setParameter("a", cust_age);
		qr.setParameter("h", cust_address);
		qr.setParameter("p", cust_phone);
		qr.setParameter("e", cust_email);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		System.out.println("Records Updated Successfully!!!");
		tran.commit();
		System.out.print("Do You Wish to Update More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			updateCustomers();
		}else {
			System.out.println("Thanks for Updating the Customer Information!!!");
			CustomerMenu csm = new CustomerMenu();
		}
	}

	//Delete Customer
	public static void deleteCustomers() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("delete from Customer where cust_id=:i");
		System.out.print("Enter the ID of Customer");
		int cust_id = input.nextInt();
		qr.setParameter("i", cust_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		System.out.println("Records Deleted Successfully!!!");
		tran.commit();
		System.out.print("Do You Wish to Delete More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			deleteCustomers();
		}else {
			System.out.println("Thanks for Deleting the Customer Information!!!");
			CustomerMenu csm = new CustomerMenu();
		}
	}
	
	//Get all Customer Information
	public static void getCustomer() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		TypedQuery qr = session.createQuery("from Customer"); 
		List<Customer> customers = qr.getResultList();
		Iterator<Customer> itr = customers.iterator();
		System.out.println("************************************************************************Display Customer Details**********************************************************************************************");
		while(itr.hasNext()) {
			Customer cust = itr.next();
			System.out.println("Customer ID = " + cust.getCust_id() + " , " 
					+ "Customer Name = "+ cust.getCust_name() + " , " + "Customer Gender = " + cust.getCust_gender() + " , " + "Customer Age = " + cust.getCust_age() + " , "
					+ " Customer Address = "+ cust.getCust_address() + " , " + "Customer Phone No = " + cust.getCust_phone() + " , " + "Customer Email = " + cust.getCust_email());
		}
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		CustomerMenu csm = new CustomerMenu();

	}
	
	//Get Individual Customer Information
	public static void getIndividualCustomer() {
		Scanner input = new Scanner(System.in);
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Query query = session.createQuery("FROM Customer C WHERE C.cust_id = :i");
		System.out.print("Enter the ID of Customer : - ");
		int cust_id = input.nextInt();
		query.setParameter("i", cust_id);
		List<Customer> results = query.list();
		Iterator<Customer> itr = results.iterator();
		System.out.println("************************************************************************Display Customer Details**********************************************************************************************");
		while(itr.hasNext()) {
			Customer cust = itr.next();
			System.out.println("Customer ID = " + cust.getCust_id() + " , " 
					+ "Customer Name = "+ cust.getCust_name() + " , " + "Customer Gender = " + cust.getCust_gender() + " , " + "Customer Age = " + cust.getCust_age() + " , "
					+ " Customer Address = "+ cust.getCust_address() + " , " + "Customer Phone No = " + cust.getCust_phone() + " , " + "Customer Email = " + cust.getCust_email());
		}
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.print("Do You Wish to See More ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			getIndividualCustomer();
		}else {
			System.out.println("Thanks for Displaying the Individual Customer Information!!!");
			CustomerMenu csm = new CustomerMenu();
		}
	}
}
