package com.dao;

import org.hibernate.cfg.Configuration;

public class ConfigurationDao {
	public static Configuration getCustomConfig() {
		Configuration conf = new Configuration();
		conf.configure();
		return conf;
	}
}
