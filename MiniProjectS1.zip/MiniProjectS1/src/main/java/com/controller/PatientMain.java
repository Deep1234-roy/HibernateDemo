package com.controller;

import java.util.Scanner;

public class PatientMain {
	public static void main(String[] args) {
		Patientcontroller obj = new Patientcontroller();
		Scanner input = new Scanner(System.in);
		System.out.println("----Menu---------");
		System.out.println("1.Add Patient \n2.Update \n3.Delete \n4.Display");
		System.out.println("-----------------");
		System.out.println("Please Enter your choice");
		int choice = input.nextInt();
		if(choice==1) {
		obj.addPatient();
		}else if(choice==2) {
			obj.updatePatient();
		}else if(choice==3) {
			obj.deletePatient();
		}else if(choice==4) {
			obj.getPatient();
		}

	}


}
