package com.controller;

import java.util.Scanner;

public class DoctorMain {
	public static void main(String[] args) {
		Doctorcontroller obj = new Doctorcontroller();
		Scanner input = new Scanner(System.in);
		System.out.println("----Menu---------");
		System.out.println("1.Add Doctor \n2.Update \n3.Delete \n4.Display");
		System.out.println("-----------------");
		System.out.println("Please Enter your choice");
		int choice = input.nextInt();
		if(choice==1) {
		obj.addDoctor();
		}else if(choice==2) {
			obj.updateDoctor();
		}else if(choice==3) {
			obj.deleteDoctor();
		}else if(choice==4) {
			obj.getDoctor();
		}

	}

}



