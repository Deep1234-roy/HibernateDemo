package com.shopping.presentation;

import java.util.Iterator;
import java.util.List;

import com.shopping.dao.ProductDaoImpl;
import com.shopping.model.Product;

public class MainClass {

	public static void main(String[] args) {
		ProductDaoImpl obj = new ProductDaoImpl();
		obj.insertProduct();
//		obj.deleteProduct();
//		obj.updateProduct();
//		List<Product> list= obj.getProducts();
//		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
//			Product product = (Product) iterator.next();
//			System.out.println("Prod ID ="+product.getProd_id()+" Product Name ="+
//			product.getProd_name()+" Product Price ="+product.getProd_price());	
//		}

	}

}
