package com.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.shopping.model.Product;

public class ProductDaoImpl implements ProductDao {
	//scanner object to take input runtime
	Scanner input = new Scanner(System.in);
	
	//Object of POJO/BEan class /
	Product prod = new Product();
	
	//step 1 - register driver
	//step 2. getConnection
	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP48-MSL1\\SQLEXPRESS2019;databaseName=ProductManagment;user=sa;password=password_123");
			System.out.println("Connected");
			
		} catch (ClassNotFoundException | SQLException e) {	
		}	
		return con;
	}

	@Override
	public void insertProduct(){
		System.out.println("Enter the Name of Product");
		String prod_name = input.next();
		System.out.println("Enter the Price of Product");
		float prod_price=input.nextFloat();
		prod.setProd_name(prod_name);
		prod.setProd_price(prod_price);
		Connection con= getConnection();
		try {
			PreparedStatement stmt = con.prepareStatement("insert into Product values(?,?)");
			stmt.setString(1, prod.getProd_name());
			stmt.setFloat(2, prod.getProd_price());
			stmt.executeUpdate();
			System.out.println("Product Inserted");
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void deleteProduct() {
		System.out.println("Enter the ID of Product");
		int prod_id = input.nextInt();
		prod.setProd_id(prod_id);
		Connection con= getConnection();
		try {
			PreparedStatement stmt = con.prepareStatement("delete from Product where prod_id=?");
			stmt.setInt(1, prod.getProd_id());
			stmt.executeUpdate();
			System.out.println("Product Deleted");
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}		
	}

	@Override
	public void updateProduct() {
		System.out.println("Enter the ID of Product");
		int prod_id = input.nextInt();
		System.out.println("Enter the Price of Product");
		float prod_price=input.nextFloat();
		prod.setProd_id(prod_id);
		prod.setProd_price(prod_price);
		Connection con= getConnection();
		try {
			PreparedStatement stmt = con.prepareStatement("update Product set prod_price=? where prod_id=?");
			stmt.setFloat(1, prod.getProd_price());
			stmt.setInt(2, prod.getProd_id());
			stmt.executeUpdate();
			System.out.println("Product Updated");
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public List<Product> getProducts() {
		List<Product> list =new ArrayList();
		Connection con= getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Product");
			while(rs.next()) {
				prod = new Product(rs.getInt(1),rs.getString(2),rs.getFloat(3));
				list.add(prod);
			}
			con.close();
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return list;
	}

}
