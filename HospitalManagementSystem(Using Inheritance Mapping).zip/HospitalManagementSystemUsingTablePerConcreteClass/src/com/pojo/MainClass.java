package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("**********HOSPITAL MANAGEMENT SYSTEM*************");
		Configuration conf = new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Patient patient = new Patient();
		patient.setPatient_name("Devraj Nandi");
		patient.setPatient_age(25);
		
		OPDPatient opd = new OPDPatient();
		opd.setPatient_name("Adhiraj Dev");
		opd.setPatient_age(29);
		opd.setPatient_symptoms("Anxiety");
		opd.setPatient_illness("Depression");
		
		AdmittedPatients adm = new AdmittedPatients();
		adm.setPatient_name("John Luther");
		adm.setPatient_age(46);
		adm.setBed_number(1005);
		adm.setDoctor_name("J.P. Dongo");
		adm.setAdm_date("09/19/2021");
		adm.setFile_number(35);
		
		session.save(patient);
		session.save(opd);
		session.save(adm);
		trans.commit();
		System.out.println("Patient Record has been added in Database!!!");

	}

}
