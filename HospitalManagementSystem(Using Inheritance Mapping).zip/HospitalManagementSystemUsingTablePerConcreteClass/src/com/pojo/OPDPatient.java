package com.pojo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="OPDPatientsRecords")
@AttributeOverrides({
@AttributeOverride(name="reg_no",column=@Column(name="reg_no")),
@AttributeOverride(name="patient_name",column = @Column(name="patient_name")),
@AttributeOverride(name="patient_age",column = @Column(name="patient_age"))
})
public class OPDPatient extends Patient {
	private String patient_symptoms;
	private String patient_illness;
	public String getPatient_symptoms() {
		return patient_symptoms;
	}
	public void setPatient_symptoms(String patient_symptoms) {
		this.patient_symptoms = patient_symptoms;
	}
	public String getPatient_illness() {
		return patient_illness;
	}
	public void setPatient_illness(String patient_illness) {
		this.patient_illness = patient_illness;
	}
	
	
}
