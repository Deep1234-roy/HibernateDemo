package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("**********HOSPITAL MANAGEMENT SYSTEM*************");
		Configuration conf = new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Patient patient = new Patient();
		patient.setPatient_name("Bony Sengupta");
		patient.setPatient_age(35);
		
		OPDPatient opd = new OPDPatient();
		opd.setReg_no(101);
		opd.setPatient_name("Mukesh Kalkari");
		opd.setPatient_age(53);
		opd.setPatient_symptoms("High Fever & Headaches");
		opd.setPatient_illness("Allergies");
		
		AdmittedPatients adm = new AdmittedPatients();
		adm.setReg_no(102);
		adm.setPatient_name("J");
		adm.setPatient_age(34);
		adm.setBed_number(1002);
		adm.setDoctor_name("Kunal Sarkar");
		adm.setAdm_date("06/17/2019");
		adm.setFile_number(22);
		
		session.save(patient);
		session.save(opd);
		session.save(adm);
		trans.commit();
		System.out.println("Patient Record has been added in Database!!!");

	}

}
