package com.pojo;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("AdmittedPatient")
public class AdmittedPatients extends Patient {
	private int bed_number;
	private String adm_date;
	private String doctor_name;
	private int file_number;
	public int getBed_number() {
		return bed_number;
	}
	public void setBed_number(int bed_number) {
		this.bed_number = bed_number;
	}
	public String getAdm_date() {
		return adm_date;
	}
	public void setAdm_date(String adm_date) {
		this.adm_date = adm_date;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public int getFile_number() {
		return file_number;
	}
	public void setFile_number(int file_number) {
		this.file_number = file_number;
	}
	
	
}
