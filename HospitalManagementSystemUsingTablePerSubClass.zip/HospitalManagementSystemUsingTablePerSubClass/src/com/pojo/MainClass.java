package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("**********HOSPITAL MANAGEMENT SYSTEM*************");
		Configuration conf = new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Patient patient = new Patient();
		patient.setPatient_name("Pallav Mahato");
		patient.setPatient_age(30);
		
		OPDPatient opd = new OPDPatient();
		opd.setPatient_name("Shankar Singh");
		opd.setPatient_age(57);
		opd.setPatient_symptoms("Fatigue");
		opd.setPatient_illness("Stomach Aches");
		
		AdmittedPatients adm = new AdmittedPatients();
		adm.setPatient_name("Tony Louis");
		adm.setPatient_age(40);
		adm.setBed_number(1007);
		adm.setDoctor_name("Sandy Paul");
		adm.setAdm_date("09/11/2019");
		adm.setFile_number(26);
		
		session.save(patient);
		session.save(opd);
		session.save(adm);
		trans.commit();
		System.out.println("Patient Record has been added in Database!!!");

	}

}
