package com.persistent;

import javax.persistence.*;

@Entity
@Table(name = "AnnnEcoCar")
@AttributeOverrides({ @AttributeOverride(name = "cheis_number", column = @Column(name = "unique_number")),
		@AttributeOverride(name = "car_name", column = @Column(name = "car_name")) })
public class EconomicalCar extends Car {
	@Column(name = "car_milage")
	private float car_milage;
	@Column(name = "car_price")
	private float car_price;

	public float getCar_milage() {
		return car_milage;
	}

	public void setCar_milage(float car_milage) {
		this.car_milage = car_milage;
	}

	public float getCar_price() {
		return car_price;
	}

	public void setCar_price(float car_price) {
		this.car_price = car_price;
	}

}
