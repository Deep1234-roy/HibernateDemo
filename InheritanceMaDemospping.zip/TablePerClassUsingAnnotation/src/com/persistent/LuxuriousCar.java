package com.persistent;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "AnnnLuxCar")
@AttributeOverrides({ @AttributeOverride(name = "cheis_number", column = @Column(name = "unique_number")),
		@AttributeOverride(name = "car_name", column = @Column(name = "car_name")) })

public class LuxuriousCar extends Car{
	@Column(name = "engine_capacity")
	private int engine_capacity;
	@Column(name = "car_feature")
	private String car_feature;
	public int getEngine_capacity() {
		return engine_capacity;
	}
	public void setEngine_capacity(int engine_capacity) {
		this.engine_capacity = engine_capacity;
	}
	public String getCar_feature() {
		return car_feature;
	}
	public void setCar_feature(String car_feature) {
		this.car_feature = car_feature;
	}
	

}
