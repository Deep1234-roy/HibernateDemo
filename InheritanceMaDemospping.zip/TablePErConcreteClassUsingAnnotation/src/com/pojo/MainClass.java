package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {
	public static void main(String[] args) {
		Configuration conf = new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		Car car = new Car();
		car.setCar_name("Jeep");
		
		EconomicalCar ecoCar = new EconomicalCar();
		ecoCar.setCar_name("Tiago");
		ecoCar.setCar_price(6.4f);
		ecoCar.setCar_milage(20.5f);
		
		LuxuriousCar luxCar = new LuxuriousCar();
		luxCar.setCar_name("Jeep Compas");
		luxCar.setEngine_capacity(3000);
		luxCar.setCar_features("Fully Loaded");
		
		session.persist(car);
		session.persist(ecoCar);
		session.persist(luxCar);
		trans.commit();
		System.out.println("Table created And data added");

	}
}
