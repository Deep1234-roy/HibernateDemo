package com.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class Main {

	public static void main(String[] args) {
		//create object of configuration for getting hibernate configuration
		Configuration conf = new Configuration();
		conf.configure();
		
		SessionFactory sf= conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		//Create objects of our pojo/persistent class
		Car car = new Car();
		car.setCar_name("Maruti Ertiga");
		
		EconomicalCar ecocar = new EconomicalCar();
		ecocar.setCar_name("Maruti Swift Desire");
		ecocar.setCar_milage(25.5f);
		ecocar.setCar_price(8.5f);
		
		LuxuriousCar luxcar = new LuxuriousCar();
		luxcar.setCar_name("Audi Q7");
		luxcar.setCar_feature("Fully Loaded");
		
		session.save(car);
		session.save(ecocar);
		session.save(luxcar);
		
		trans.commit();
		System.out.println("Done ...");
		
		
		

	}

}
