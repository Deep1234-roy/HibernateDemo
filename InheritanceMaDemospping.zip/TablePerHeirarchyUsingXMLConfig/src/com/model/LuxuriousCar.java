package com.model;

public class LuxuriousCar extends Car{
	private int engine_capacity;
	private String car_feature;
	public int getEngine_capacity() {
		return engine_capacity;
	}
	public void setEngine_capacity(int engine_capacity) {
		this.engine_capacity = engine_capacity;
	}
	public String getCar_feature() {
		return car_feature;
	}
	public void setCar_feature(String car_feature) {
		this.car_feature = car_feature;
	}
	

}
