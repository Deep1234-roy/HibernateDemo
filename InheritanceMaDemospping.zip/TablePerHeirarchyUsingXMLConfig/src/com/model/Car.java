package com.model;

public class Car {
	private int cheis_number;
	private String car_name;
	public int getCheis_number() {
		return cheis_number;
	}
	public void setCheis_number(int cheis_number) {
		this.cheis_number = cheis_number;
	}
	public String getCar_name() {
		return car_name;
	}
	public void setCar_name(String car_name) {
		this.car_name = car_name;
	}
	

}
