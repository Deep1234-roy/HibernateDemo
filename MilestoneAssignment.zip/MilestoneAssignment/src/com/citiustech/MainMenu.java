package com.citiustech;

import java.util.Scanner;
public class MainMenu {
		MainMenu(){
			Scanner input = new Scanner(System.in);
			int choice = 0;
		do {
			System.out.println("---------------Menu----------------");
			System.out.println("    1.        Mobile");
			System.out.println("    2.        Laptop");
			System.out.println("    3.        TV");
			System.out.println("    4.        Home Appliances");
			System.out.println("    0.        Exit");
			System.out.print("Please Select Category: ");
			choice = input.nextInt();
			if(choice == 1) {
				Mobile obj = new Mobile();
			}else if(choice == 2) {
				Laptop obj = new Laptop();
			}else if(choice == 3) {
				TV obj = new TV();
			}else if(choice == 4) {
				HomeAppliances obj = new HomeAppliances();
			}else {
				System.out.println("Thank you for closing our application!!");
				System.exit(0);
			}
		}while(choice != 0);
		}


}
