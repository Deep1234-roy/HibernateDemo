package com.citiustech;

public class Main {

	public static void main(String[] args) {
		ValidateUser obj1 = new ValidateUser();
		if(obj1.validateUser() == true) {
			MainMenu obj = new MainMenu();
		}else {
			System.out.println("You are not an Authorized User!!");
		}

	}

}
