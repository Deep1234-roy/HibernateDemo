package com.citiustech;

import java.util.Scanner;

public class TV {
	Scanner input = new Scanner(System.in);
	int product;
	TV(){
		System.out.println("---------------TV----------------");
		System.out.println("  SL.NO.     Brand Name      Price ");
		System.out.println("    1.        Panasonic      58000");
		System.out.println("    2.     Blaupunkt Cyber   20999");
		System.out.println("    3.        Samsung        37000");
		System.out.println("    0.        Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Panasonic TV");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Blaupunkt Cyber TV");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- Samsung TV");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the TV Menu!!");
			MainMenu obj = new MainMenu();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=58000;
		}else if(product == 2) {
			price=20999;
		}else if(product==3) {
			price=37000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			TV obj = new TV();
		}else {
			System.out.println("Thanks for closing the TV Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}
