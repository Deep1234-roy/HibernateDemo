package com.citiustech;

import java.util.Scanner;
public class Mobile {
	Scanner input = new Scanner(System.in);
	int product;
	Mobile(){
		System.out.println("---------------Mobile----------------");
		System.out.println("  SL.NO.      Brand Name     Price ");
		System.out.println("    1.        Iphone 13      45000");
		System.out.println("    2.        Lenovo 17      19000");
		System.out.println("    3.        Micromax 20    28000");
		System.out.println("    4.        Realme c2      30000");
		System.out.println("    0.        Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Iphone 13");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Lenovo 17");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- Micromax 20");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 4:
			System.out.println("You have selected:- Realme C2");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the Mobile Menu!!");
			MainMenu obj = new MainMenu();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=45000;
		}else if(product == 2) {
			price=19000;
		}else if(product==3) {
			price=28000;
		}else if(product==4) {
			price=30000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			Mobile obj = new Mobile();
		}else {
			System.out.println("Thanks for closing the Mobile Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}

