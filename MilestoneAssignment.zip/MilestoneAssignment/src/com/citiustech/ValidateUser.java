package com.citiustech;

import java.util.Scanner;
public class ValidateUser {
	
	public boolean validateUser() {
		boolean login=false;
		Scanner input=new Scanner(System.in);
		String username = "Deep";
		String password = "Deep1234";
		System.out.print("Enter User Name:- ");
		String uName = input.next();
		System.out.print("Enter User Password:- ");
		String uPass = input.next();
		if(uName.equals(username) && uPass.equals(password)) {
			System.out.println("---------------Welcome to Our Site-------------------");
			login=true;
		}else {
			System.out.println("Your Username or Password is incorrect!!!!");
			login=false;
		}
		return login;
	}
}
