package com.citiustech;

import java.util.Scanner;

public class HomeAppliances {
	Scanner input = new Scanner(System.in);
	int product;
	HomeAppliances(){
		System.out.println("---------------Home Appliances----------------");
		System.out.println("  SL.NO.     Brand Name      Price ");
		System.out.println("    1.       Refrigerator    60000");
		System.out.println("    2.       Microwave       10000");
		System.out.println("    3.        Mixer          5000");
		System.out.println("    0.        Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Refrigerator");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Microwave");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- Mixer");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the Home Appliances Menu!!");
			MainMenu obj = new MainMenu();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=60000;
		}else if(product == 2) {
			price=10000;
		}else if(product==3) {
			price=5000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			HomeAppliances obj = new HomeAppliances();
		}else {
			System.out.println("Thanks for closing the Home Appliances Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}
