package com.citiustech;

import java.util.Scanner;

public class Laptop {
	Scanner input = new Scanner(System.in);
	int product;
	Laptop(){
		System.out.println("---------------Laptop----------------");
		System.out.println("  SL.NO.     Brand Name      Price ");
		System.out.println("    1.        Dell           50000");
		System.out.println("    2.     Lenovo Thinkpad   70000");
		System.out.println("    3.        Asus           40000");
		System.out.println("    0.        Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Dell Laptop");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Lenovo Thinkpad Laptop");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- Asus Laptop");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the Laptop Menu!!");
			MainMenu obj = new MainMenu();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=50000;
		}else if(product == 2) {
			price=70000;
		}else if(product==3) {
			price=40000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			Laptop obj = new Laptop();
		}else {
			System.out.println("Thanks for closing the Laptop Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}
