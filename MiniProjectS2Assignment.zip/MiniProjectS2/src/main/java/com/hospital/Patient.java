package com.hospital;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Patient")
public class Patient {
	@Id
	
	private int  pati_filenumber;
	private String pati_name;
	private String pati_problem;
	private String pati_age;
	private String pati_address;
	private String pati_phonenumber;
	private String doctor_list;
	
	@ManyToOne
	private Doctor doctor;

	public int getPati_filenumber() {
		return pati_filenumber;
	}

	public void setPati_filenumber(int pati_filenumber) {
		this.pati_filenumber = pati_filenumber;
	}

	public String getPati_name() {
		return pati_name;
	}

	public void setPati_name(String pati_name) {
		this.pati_name = pati_name;
	}

	public String getPati_problem() {
		return pati_problem;
	}

	public void setPati_problem(String pati_problem) {
		this.pati_problem = pati_problem;
	}

	public String getPati_age() {
		return pati_age;
	}

	public void setPati_age(String pati_age) {
		this.pati_age = pati_age;
	}

	public String getPati_address() {
		return pati_address;
	}

	public void setPati_address(String pati_address) {
		this.pati_address = pati_address;
	}

	public String getPati_phonenumber() {
		return pati_phonenumber;
	}

	public void setPati_phonenumber(String pati_phonenumber) {
		this.pati_phonenumber = pati_phonenumber;
	}

	public String getDoctor_list() {
		return doctor_list;
	}

	public void setDoctor_list(String doctor_list) {
		this.doctor_list = doctor_list;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

}