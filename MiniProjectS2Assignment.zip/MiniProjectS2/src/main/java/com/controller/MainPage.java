package com.controller;

import java.util.Scanner;

public class MainPage {
	public static void main(String[] args) {
		System.out.println("-----MENU-----");
		System.out.println("1.PATIENT");
		System.out.println("2.DOCTOR");
		System.out.println("0.exit");
		Scanner input = new Scanner(System.in);
		System.out.println("Please Select a Category:");
		int category = input.nextInt();
		switch(category)
		{
		case 1: 
			PatientMain p = new PatientMain();
			
			p.main(args);
			break;
		case 2:
			DoctorMain d = new DoctorMain();
			d.main(args);
			break;
		default :
			System.out.println("-----------------thankyou---------------");
		}
	}
	

}



