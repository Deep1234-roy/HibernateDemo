package com.controller;

import java.lang.module.Configuration;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dao.PatientDao;
import com.hospital.Doctor;
import com.hospital.Patient;

public class Patientcontroller {
	static org.hibernate.cfg.Configuration conf = PatientDao.getPatientConfig();
	// creating persistent object for persistent class
	static Patient obj = new Patient();

	public static void addPatient() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		System.out.println("Enter the file number of Patient");
		int pati_filenumber = input.nextInt();
		System.out.println("Enter the Name of Patient");
		String pati_name = input.next();
		System.out.println("Enter the  problem of Patient");
		String pati_problem = input.next();
		System.out.println("Enter the Age of Patient");
		String pati_age = input.next();
		System.out.println("Enter the Address of Patient");
		String pati_address = input.next();
		System.out.println("Enter the phone number of Patient");
		String pati_phonenumber = input.next();
		System.out.println("Enter the Doctor one/list");
		String doctor_list = input.next();
		obj.setPati_filenumber(pati_filenumber);
		obj.setPati_name(pati_name);
		obj.setPati_problem(pati_problem);
		obj.setPati_age(pati_age);
		obj.setPati_address( pati_address);
		obj.setPati_phonenumber(pati_phonenumber);
		obj.setDoctor_list(doctor_list);
		session.save(obj);
		tran.commit();
		session.close();
		System.out.println("Patient  Added Successfully");
	}

	public static void updatePatient() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		Query qr = session.createQuery("update Patient set pati_filenumber=:fn  pati_name=:n pati_problem=:p pati_age=:ag pati_address=:a pati_phonenumber=:ph doctor_list=:l");
		System.out.println("Enter the file number of Patient");
		int pati_filenumber = input.nextInt();
		System.out.println("Enter the Name of Patient");
		String pati_name = input.next();
		System.out.println("Enter the  problem of Patient");
		String pati_problem = input.next();
		System.out.println("Enter the Age of Patient");
		String pati_age = input.next();
		System.out.println("Enter the Address of Patient");
		String pati_address = input.next();
		System.out.println("Enter the phone number of Patient");
		String pati_phonenumber = input.next();
		System.out.println("Enter the Doctor one/list");
		String doctor_list = input.next();
		qr.setParameter("fn", pati_filenumber);
		qr.setParameter("n", pati_name);
		qr.setParameter("p", pati_problem);
		qr.setParameter("ag", pati_age);
		qr.setParameter("a", pati_address);
		qr.setParameter("ph", pati_phonenumber);
		qr.setParameter("l", doctor_list);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		tran.commit();
		session.close();

	}

	public static void deletePatient() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		Query qr = session.createQuery("delete from Patient where pati_filenumber=:fn");
		System.out.println("Enter the filenumber of Patient");
		int pati_filenumber = input.nextInt();
		qr.setParameter("fn", pati_filenumber);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		tran.commit();
	}

	public static void getPatient() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		TypedQuery qr = session.createQuery("from Patient"); 
		List<Patient> patients = qr.getResultList();
		Iterator<Patient> itr = patients.iterator();
		while(itr.hasNext()) {
			Patient pati = itr.next();
			System.out.println("pati_filenumber="+pati.getPati_filenumber()
			+"pati_name = "+pati.getPati_name()+"pati_problem="+pati.getPati_problem()+"pati_age ="+pati.getPati_age()+"pati_address="+pati.getPati_address()+"pati_phonenumber="+pati.getPati_phonenumber()+"doctor_list"+pati.getDoctor_list());
		}
		
	}
}









