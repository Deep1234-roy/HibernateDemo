package com.controller;

import java.util.Scanner;

public class DoctorMenu {
	public DoctorMenu() {
		DoctorController obj = new DoctorController();
		Scanner input = new Scanner(System.in);
		System.out.println("------------------DOCTOR OPERATION------------------");
		System.out.println("1.Add Doctor \n2.Update Doctor Records \n3.Delete Doctor Records \n4.Display Doctor Records");
		System.out.println("-----------------");
		System.out.print("Please Enter your Operation : - ");
		int choice = input.nextInt();
		if(choice==1) {
		obj.addDoctor();
		}else if(choice==2) {
			obj.updateDoctor();
		}else if(choice==3) {
			obj.deleteDoctor();
		}else if(choice==4) {
			obj.getDoctor();
		}
	}
}
