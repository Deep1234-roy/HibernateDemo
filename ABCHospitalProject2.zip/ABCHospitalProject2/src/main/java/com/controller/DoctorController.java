package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.dao.DoctorDao;
import com.pojo.Doctor;

public class DoctorController {
	static org.hibernate.cfg.Configuration conf = DoctorDao.getDoctorConfig();
	// creating persistent object for persistent class
	static Doctor obj = new Doctor();

		//ADD DOCTOR
	public static void addDoctor() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		System.out.print("Enter the ID of Doctor : - ");
		int doct_id = input.nextInt();
		System.out.print("Enter the Name of Doctor : - ");
		String doct_name = input.next();
		System.out.print("Enter the  Doctor's specialty : - ");
		String doct_specialty = input.next();
		System.out.print("Enter the Address of Doctor : - ");
		String doct_address = input.next();
		System.out.print("Enter the phone number of Doctor : - ");
		String doct_phonenumber = input.next();
		System.out.print("Enter the Patient one/list : - ");
		String patie_list = input.next();
		obj.setDoct_id(doct_id);
		obj.setDoct_name(doct_name);
		obj.setDoct_specialty(doct_specialty);
		obj.setDoct_address(doct_address);
		obj.setDoct_phonenumber(doct_phonenumber);
		obj.setPatie_list(patie_list);
		session.save(obj);
		tran.commit();
		session.close();
		System.out.print("Do You Wish to Add More Doctor Records ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			addDoctor();
		}else {
			System.out.println("Thanks for Adding the Doctor Details!!!");
			DoctorMenu dm = new DoctorMenu();
		}
		System.out.println("Doctor Records Added Successfully");
	}

	//UPDATE DOCTOR
	public static void updateDoctor() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		Query qr = session.createQuery("update Doctor set doct_id=:i  doct_name=:n doct_specialty=:s doct_address=:a doct_phonenumber=:p patie_list=:l");
		System.out.print("Enter the ID of Doctor : - ");
		int doct_id = input.nextInt();
		System.out.print("Enter the Name of Doctor : - ");
		String doct_name = input.next();
		System.out.print("Enter the  Doctor's specialty : - ");
		String doct_specialty = input.next();
		System.out.print("Enter the Address of Doctor : - ");
		String doct_address = input.next();
		System.out.print("Enter the phone number of Doctor : - ");
		String doct_phonenumber = input.next();
		System.out.print("Enter the Patient one/list : - ");
		String patie_list = input.next();
		qr.setParameter("i", doct_id);
		qr.setParameter("n", doct_name);
		qr.setParameter("s", doct_specialty);
		qr.setParameter("a", doct_address);
		qr.setParameter("p", doct_phonenumber);
		qr.setParameter("l", patie_list);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		tran.commit();
		session.close();
		System.out.print("Do You Wish to Update More Doctor Records ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			updateDoctor();
		}else {
			System.out.println("Thanks for Updating the Doctor Details!!!");
			DoctorMenu dm = new DoctorMenu();
		}
		System.out.println("Doctor Records Updated Successfully");

	}

	//DELETE DOCTOR
	public static void deleteDoctor() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		Query qr = session.createQuery("delete from Doctor where doct_id=:i");
		System.out.print("Enter the ID of Doctor : - ");
		int doct_id = input.nextInt();
		qr.setParameter("i", doct_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		tran.commit();
		System.out.print("Do You Wish to Delete More Doctor Records ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			deleteDoctor();
		}else {
			System.out.println("Thanks for Deleting the Doctor Details!!!");
			DoctorMenu dm = new DoctorMenu();
		}
		System.out.println("Doctor Records Deleted Successfully");
	}

	//DISPLAY DOCTOR RECORDS
	public static void getDoctor() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		TypedQuery qr = session.createQuery("from Doctor"); 
		List<Doctor> doctors = qr.getResultList();
		Iterator<Doctor> itr = doctors.iterator();
		System.out.println("********************************************DOCTOR RECORDS************************************************");
		while(itr.hasNext()) {
			Doctor doct = itr.next();
			System.out.println("Doctor ID = "+ " " + doct.getDoct_id()
			+ "," +" Doctor Name = "+ " " + doct.getDoct_name() + "," +" Doctor specialty= "+ " " + doct.getDoct_specialty()
			+"," +" Doctor Address = "+ " " + doct.getDoct_address()+"," +" Doctor Phone number= "+ " " + doct.getDoct_phonenumber()
			+"," +" Patient list : - "+ " " + doct.getPatie_list());
		}
		DoctorMenu dm = new DoctorMenu();
		
	}
}
