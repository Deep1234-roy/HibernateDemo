package com.controller;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("****************ABC HOSPITAL****************");
		System.out.println("----------------CATEGORY----------------");
		System.out.println("1.	PATIENT "+ "\n2.	DOCTOR" + "\n0.	EXIT");
		Scanner input = new Scanner(System.in);
		System.out.print("Please Select a Category: - ");
		int category = input.nextInt();
		switch(category)
		{
		case 1: 
			PatientMenu p = new PatientMenu();
			break;
		case 2:
			DoctorMenu d = new DoctorMenu();
			break;
		case 0:
			System.out.println("Thanks for Closing our Application!!");
			System.exit(0);
			break;
		default :
			System.out.println("Please Choose Valid Options from menu!!");
		}

	}

}
