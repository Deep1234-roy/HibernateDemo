package com.controller;

import java.util.Scanner;

public class PatientMenu {
	public PatientMenu() {
		PatientController obj = new PatientController();
		Scanner input = new Scanner(System.in);
		System.out.println("------------------PATIENT OPERATION------------------");
		System.out.println("1.Add Patient \n2.Update Patient Records \n3.Delete Patient Records \n4.Display Patient Records");
		System.out.println("-----------------");
		System.out.print("Please Enter your choice : - ");
		int choice = input.nextInt();
		if(choice==1) {
		obj.addPatient();
		}else if(choice==2) {
			obj.updatePatient();
		}else if(choice==3) {
			obj.deletePatient();
		}else if(choice==4) {
			obj.getPatient();
		}

	}
}
