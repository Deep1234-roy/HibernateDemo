package com.citiustech;

import java.util.Scanner;
public class Mobile {
	Scanner input = new Scanner(System.in);
	public int product;
	Mobile(){
		System.out.println("---------------Mobile----------------");
		System.out.println("  SL.NO.     Brand Name     Price ");
		int [] SerialNo = new int[4];  //creating serial no array
		SerialNo[0]=1;
		SerialNo[1]=2;
		SerialNo[2]=3;
		SerialNo[3]=4;
		String [] Mobiles = new String[4];   //creating Mobiles array
		int [] Prices = new int[4];          //creating Price array
		Prices[0]=45000;
		Prices[1]=19000;
		Prices[2]=28000;
		Prices[3]=30000;
		Mobiles[0] = "Iphone 13";
		Mobiles[1] = "Lenovo 17";
		Mobiles[2] = "Micromax 20";
		Mobiles[3] = "Realme C2";
		for(int i=0; i<Mobiles.length; i++) {
			System.out.println("    " + SerialNo[i] + "        " + Mobiles[i] + "     " + Prices[i]);
		}
		System.out.println("    0.        Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Iphone 13");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Lenovo 17");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- Micromax 20");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 4:
			System.out.println("You have selected:- Realme C2");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the Mobile Menu!!");
			MainMenu obj4 = new MainMenu();
			break;
		default:
			System.out.println("Please choose Valid Products from Menu!!");
			Mobile obj5 = new Mobile();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=45000;
		}else if(product == 2) {
			price=19000;
		}else if(product==3) {
			price=28000;
		}else if(product==4) {
			price=30000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			System.out.println("Thanks for once again showing your interest!!");
			Mobile obj = new Mobile();
		}else {
			System.out.println("Thanks for closing the Mobile Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}

