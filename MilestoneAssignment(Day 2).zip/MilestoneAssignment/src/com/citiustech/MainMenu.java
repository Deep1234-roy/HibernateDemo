package com.citiustech;

import java.util.Scanner;
public class MainMenu {
	Scanner input = new Scanner(System.in);
		MainMenu(){
			int choice = 0;
		do {
			System.out.println("---------------Menu----------------");
			int [] SerialNo = new int[4];  //creating serial no array
			SerialNo[0]=1;
			SerialNo[1]=2;
			SerialNo[2]=3;
			SerialNo[3]=4;
			String [] Menu = new String[4]; //creating Menu Array
			Menu[0] = "Mobile";
			Menu[1] = "Laptop";
			Menu[2] = "TV";
			Menu[3] = "Home Appliances";
			for(int item=0;item<Menu.length;item++) {
				System.out.println("     " + SerialNo[item] + "        " + Menu[item]);
			}
			System.out.println("     0.       Exit");
			System.out.print("Please Select Category: ");
			choice = input.nextInt();
			if(choice == 1) {
				Mobile obj = new Mobile();
			}else if(choice == 2) {
				Laptop obj = new Laptop();
			}else if(choice == 3) {
				TV obj = new TV();
			}else if(choice == 4) {
				HomeAppliances obj = new HomeAppliances();
			}else if(choice == 0) {
				System.out.println("Thank you for closing our application!!");
				System.exit(0);
			}else {
				System.out.println("Please Select Valid Category from Menu!!");
				MainMenu obj = new MainMenu();
			}
		}while(choice != 0);		
		}
		


}
