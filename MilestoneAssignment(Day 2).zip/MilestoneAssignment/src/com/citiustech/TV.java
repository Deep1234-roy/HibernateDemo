package com.citiustech;

import java.util.Scanner;

public class TV {
	Scanner input = new Scanner(System.in);
	int product;
	TV(){
		System.out.println("---------------TV----------------");
		System.out.println("  SL.NO.     Brand Name      Price ");
		int [] SerialNo = new int[3];  //creating serial no array
		SerialNo[0]=1;
		SerialNo[1]=2;
		SerialNo[2]=3;
		String [] TVs = new String[3];   //creating TV array
		int [] Prices = new int[3];          //creating Price array
		Prices[0]=58000;
		Prices[1]=20999;
		Prices[2]=37000;
		TVs[0] = "Panasonic";
		TVs[1] = "Blaupunkt";
		TVs[2] = "SamsungZ7";
		for(int i=0; i<TVs.length; i++) {
			System.out.println("    " + SerialNo[i] + "        " + TVs[i] + "       " + Prices[i]);
		}
		System.out.println("    0.        Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Panasonic TV");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Blaupunkt TV");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- SamsungZ7 TV");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the TV Menu!!");
			MainMenu obj = new MainMenu();
			break;
		default:
			System.out.println("Please choose Valid Products from Menu!!");
			Mobile obj5 = new Mobile();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=58000;
		}else if(product == 2) {
			price=20999;
		}else if(product==3) {
			price=37000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			System.out.println("Thanks for once again showing your interest!!");
			TV obj = new TV();
		}else {
			System.out.println("Thanks for closing the TV Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}
