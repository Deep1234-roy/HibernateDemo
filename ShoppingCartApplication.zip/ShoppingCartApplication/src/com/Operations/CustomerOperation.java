package com.Operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.customer.CustomerMainMenu;
import com.products.HomeAppliances;
import com.products.Laptop;
import com.products.Mobile;

public class CustomerOperation {
	Scanner sc = new Scanner(System.in);
	public void PageTrackForMobile() throws ClassNotFoundException, SQLException, IOException {
		System.out.print("Do You Wish to Continue? ");
		String choice = sc.next();
		if(choice.equalsIgnoreCase("Yes")) {
			System.out.println("Thanks for once again showing your interest!!");
			Mobile mob = new Mobile();
		}else {
			System.out.println("Thanks for closing the Mobile Menu!!");
			CustomerMainMenu csm = new CustomerMainMenu();
		}
	}
	public void PageTrackForLaptop() throws ClassNotFoundException, SQLException, IOException {
		System.out.print("Do You Wish to Continue? ");
		String choice = sc.next();
		if(choice.equalsIgnoreCase("Yes")) {
			System.out.println("Thanks for once again showing your interest!!");
			Laptop lpt = new Laptop();
		}else {
			System.out.println("Thanks for closing the Laptop Menu!!");
			CustomerMainMenu csm = new CustomerMainMenu();
		}
	}
	public void PageTrackForHomeAppliances() throws ClassNotFoundException, SQLException, IOException {
		System.out.print("Do You Wish to Continue? ");
		String choice = sc.next();
		if(choice.equalsIgnoreCase("Yes")) {
			System.out.println("Thanks for once again showing your interest!!");
			HomeAppliances ha = new HomeAppliances();
		}else {
			System.out.println("Thanks for closing the Home Appliances Menu!!");
			CustomerMainMenu csm = new CustomerMainMenu();
		}
	}
}
