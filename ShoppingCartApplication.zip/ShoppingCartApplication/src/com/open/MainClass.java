package com.open;

import java.io.IOException;
import java.sql.SQLException;

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		SecondMenu sm = new SecondMenu();
		sm.SecondMenu();
	}

}
