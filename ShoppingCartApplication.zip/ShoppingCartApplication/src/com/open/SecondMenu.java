package com.open;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.Admin.AdminMenu;
import com.customer.CustomerMainMenu;
import com.validation.AdminValidation;
import com.validation.CustomerValidation;

public class SecondMenu {
	Scanner sc = new Scanner(System.in);
	public void SecondMenu() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		System.out.println("-----------Welcome to DEEP Store----------------");
		System.out.println("Are you : -");
		System.out.println();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("Select * from mainRole");
		System.out.println("Sl.No." + "   " + "Role");
		while(rs.next()) {
			System.out.println(rs.getInt(1)  + "        " +  rs.getString(2));
		}
		System.out.println(0 + "        " + "Exit");
		System.out.print("Please Select your Role :- ");
		int ch  = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("You have selected your role as an Admin!!!!");
			System.out.println("**********************ADMIN MODULE**************************");
			AdminValidation adm = new AdminValidation();
			if(adm.AdminCredentials() == true) {
				System.out.println("You have successfully Logged in as an Admin!!");
				AdminMenu obj = new AdminMenu();
			}else {
				System.out.println("You are not an Valid Admin!!");
				SecondMenu();
			}
			break;
		case 2:
			System.out.println("You have selected your role as a Customer!!!!");
			System.out.println("**********************CUSTOMER MODULE**************************");
			CustomerValidation cst = new CustomerValidation();
			if(cst.CustomerCredentials() == true) {
				System.out.println("You have successfully Logged in as an Customer!!");
				CustomerMainMenu cstmenu = new CustomerMainMenu();
			}else {
				System.out.println("You are not an Valid Customer!!");
				SecondMenu();
			}
			break;
		case 0:
			System.out.println("Thanks for Closing our Application!!!!");
			System.exit(0);
			break;
		default:
			System.out.println("Please Choose Valid Role from above!!");
			SecondMenu smenu = new SecondMenu();
		}
		
		con.close();
	}
}
