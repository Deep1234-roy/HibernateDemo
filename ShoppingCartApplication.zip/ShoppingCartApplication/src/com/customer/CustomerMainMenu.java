package com.customer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.open.SecondMenu;
import com.products.HomeAppliances;
import com.products.Laptop;
import com.products.Mobile;

public class CustomerMainMenu {
	Scanner sc = new Scanner(System.in);
	public CustomerMainMenu() throws ClassNotFoundException, SQLException, IOException{
		System.out.println("---------------------START SHOPPING--------------------------");
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from CustomerMenu");
		System.out.println("SL.NO." + "     " + "Operation");
		while(rs.next()) {
			System.out.println(rs.getInt(1) + "           " + rs.getString(2));
		}
		System.out.println(0 + "           " + "Exit");
		System.out.print("Please Select your Category : ");
		int ch = sc.nextInt();
		if(ch == 1) {
			Mobile mob = new Mobile();
		}else if(ch == 2) {
			Laptop lpt = new Laptop();
		}else if(ch == 3) {
			HomeAppliances hapl = new HomeAppliances();
		}else if(ch == 4) {
			//GetInvoice giv = new GetInvoice();
		}else if(ch == 0) {
			System.out.println("Thank you for closing Customer Menu!!");
			SecondMenu obj = new SecondMenu();
			obj.SecondMenu();
		}else {
			System.out.println("Please Select Valid Category from Customer Menu!!");
			CustomerMainMenu cst = new CustomerMainMenu();
		}
		con.close();
	}
}
