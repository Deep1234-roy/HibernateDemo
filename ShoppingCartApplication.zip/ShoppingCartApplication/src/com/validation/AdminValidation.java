package com.validation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AdminValidation {
	public boolean AdminCredentials() throws ClassNotFoundException, SQLException {
		boolean login = false;
		Scanner sc = new Scanner(System.in);
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		try {
		System.out.print("Enter the Admin UserName(Admin) : - ");
		String name = sc.next();
		System.out.print("Enter the Admin Password(7980) : -");
		int pwd = sc.nextInt();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("Select * from adminCreden");
			while(rs.next()) {
				if(name.equals(rs.getString(1)) && pwd == rs.getInt(2)) {
					login=true;
				}
			}
				}catch(InputMismatchException ex) {
					System.out.println("Your Admin UserName or Password is incorrect!!!!");
					login=false;
				}
		return login;
	}
	
}
