package com.validation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CustomerValidation {
	public boolean CustomerCredentials() throws ClassNotFoundException, SQLException {
		boolean login = false;
		Scanner sc = new Scanner(System.in);
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		try {
			System.out.print("Enter the Customer UserName(Deep) : - ");
			String name = sc.next();
			System.out.print("Enter the Customer Password(1234) : -");
			int pwd = sc.nextInt();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from customerCreden");
			while(rs.next()) {
				if(name.equals(rs.getString(1)) && pwd == rs.getInt(2)) {
					login=true;
				}
			}
		}catch(InputMismatchException ex) {
			System.out.println("Your Customer UserName or Password is incorrect!!!!");
			login=false;
		}
		return login;
	}
}
