package com.products;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.Operations.CustomerOperation;
import com.customer.CustomerMainMenu;

public class Mobile {
	Scanner input = new Scanner(System.in);
	public int product;
	public Mobile() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from Mobiles");
		System.out.println("---------------Mobile----------------");
		System.out.println("Product ID"+ "     " + " Brand Name " + "    " + " Price ");
		while(rs.next()) {
			System.out.println(rs.getInt(1) + "           " + rs.getString(2) + "       " + rs.getInt(3));
		}
		System.out.println(0 + "           " + "Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			ResultSet rs1 = stmt.executeQuery("select * from Mobiles where SerialNo=1");
			CustomerOperation cop = new CustomerOperation();
			while(rs1.next()) {
				System.out.println("You have Selected : " + rs1.getString("Mobile"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs1.getInt("Price"));
				System.out.println();
				cop.PageTrackForMobile();
			}
			break;
		case 2:
			ResultSet rs2 = stmt.executeQuery("select * from Mobiles where SerialNo=2");
			CustomerOperation cop1 = new CustomerOperation();
			while(rs2.next()) {
				System.out.println("You have Selected : " + rs2.getString("Mobile"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs2.getInt("Price"));
				System.out.println();
				cop1.PageTrackForMobile();
			}
			break;
		case 3:
			ResultSet rs3 = stmt.executeQuery("select * from Mobiles where SerialNo=3");
			CustomerOperation cop2 = new CustomerOperation();
			while(rs3.next()) {
				System.out.println("You have Selected : " + rs3.getString("Mobile"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs3.getInt("Price"));
				System.out.println();
				cop2.PageTrackForMobile();
			}
			break;
		case 4:
			ResultSet rs4 = stmt.executeQuery("select * from Mobiles where SerialNo=4");
			CustomerOperation cop3 = new CustomerOperation();
			while(rs4.next()) {
				System.out.println("You have Selected : " + rs4.getString("Mobile"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs4.getInt("Price"));
				System.out.println();
				cop3.PageTrackForMobile();
			}
			break;
		case 0:
			System.out.println("Thanks for closing the Mobile Menu!!!");
			CustomerMainMenu cst = new CustomerMainMenu();
			break;
		default:
			System.out.println("Please choose Valid Products from Mobile Menu!!");
			Mobile obj = new Mobile();
		}
		con.close();
	}
}
