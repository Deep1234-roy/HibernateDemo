package com.products;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.Operations.CustomerOperation;
import com.customer.CustomerMainMenu;

public class Laptop {
	Scanner input = new Scanner(System.in);
	public int product;
	public Laptop() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from Laptops");
		System.out.println("---------------Laptop----------------");
		System.out.println("Product ID"+ "     " + " Brand Name " + "    " + " Price ");
		while(rs.next()) {
			System.out.println(rs.getInt(1) + "             " + rs.getString(2) + "           " + rs.getInt(3));
		}
		System.out.println(0 + "            " + "Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			ResultSet rs1 = stmt.executeQuery("select * from Laptops where SerialNo=1");
			CustomerOperation cop = new CustomerOperation();
			while(rs1.next()) {
				System.out.println("You have Selected : " + rs1.getString("Laptop"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs1.getInt("Price"));
				System.out.println();
				cop.PageTrackForLaptop();
			}
			break;
		case 2:
			ResultSet rs2 = stmt.executeQuery("select * from Laptops where SerialNo=2");
			CustomerOperation cop1 = new CustomerOperation();
			while(rs2.next()) {
				System.out.println("You have Selected : " + rs2.getString("Laptop"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs2.getInt("Price"));
				System.out.println();
				cop1.PageTrackForLaptop();
			}
			break;
		case 3:
			ResultSet rs3 = stmt.executeQuery("select * from Laptops where SerialNo=3");
			CustomerOperation cop2 = new CustomerOperation();
			while(rs3.next()) {
				System.out.println("You have Selected : " + rs3.getString("Laptop"));
				System.out.print("Please Enter your Quantity : ");
				int quant = input.nextInt();
				System.out.print("Total Bill is : - " + quant * rs3.getInt("Price"));
				System.out.println();
				cop2.PageTrackForLaptop();
			}
			break;
		case 0:
			System.out.println("Thanks for closing the Laptop Menu!!!");
			CustomerMainMenu cst = new CustomerMainMenu();
			break;
		default:
			System.out.println("Please choose Valid Products from Laptop Menu!!");
			Laptop obj = new Laptop();
		}
		con.close();
	}
}
