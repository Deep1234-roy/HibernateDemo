package com.Admin.Operations;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.Admin.AdminMenu;

public class CustomerReport {
	public void CustomerReportGenerate() throws ClassNotFoundException, SQLException, IOException {
		DisplayCustomer dsl = new DisplayCustomer();
		List lst = dsl.DisplayCustomer();
		File file = new File("C:\\Users\\Deepr\\Documents\\Deep\\CustomerDetails.txt");
		BufferedWriter out = new BufferedWriter(new FileWriter(file,true));
		for(Object s: lst) {
			out.write((char) s);
			out.newLine();
		}
		Scanner data = new Scanner(file);
		while(data.hasNextLine()) {
			String data1 = data.nextLine();
			System.out.println(data1);
		}
		AdminMenu admenu = new AdminMenu();
		out.close();
	}
}
