package com.Admin.Operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.Admin.AdminMenu;

public class DeleteProduct {
	Scanner sc = new Scanner(System.in);
	public DeleteProduct() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		System.out.print("How many Products do you want to Delete? : ");
		int dltProd = sc.nextInt();
		for(int i=0; i<dltProd; i++) {
			System.out.print("Enter the Product ID which you want to delete : ");
			int id = sc.nextInt();
			PreparedStatement pst = con.prepareStatement("delete from AdminAddProduct where ProductId=?");
			pst.setInt(1, id);
			pst.executeUpdate();
		}
		System.out.println("Record Deleted Successfully!!!");
		AdminMenu admenu = new AdminMenu();
		con.close();
	}
}
