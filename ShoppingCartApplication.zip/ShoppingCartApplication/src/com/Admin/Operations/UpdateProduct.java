package com.Admin.Operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.Admin.AdminMenu;

public class UpdateProduct {
	Scanner sc = new Scanner(System.in);
	public UpdateProduct() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		System.out.print("How Many Products do you want to Update? : ");
		int upd_pro = sc.nextInt();
		for(int i=0;i<upd_pro; i++) {
			System.out.print("Enter the Product ID For Which You want to Update : ");
			int id = sc.nextInt();
			System.out.print("Enter the Product Price For Which You want to Update : ");
			int price = sc.nextInt();
			PreparedStatement pst = con.prepareStatement("update AdminAddProduct set Price = ? where ProductId = ?");
			pst.setInt(1, price);
			pst.setInt(2, id);
			pst.executeUpdate();
		}
		System.out.println("Record Updated Successfully!!!");
		AdminMenu admenu = new AdminMenu();
		con.close();
	}
}
