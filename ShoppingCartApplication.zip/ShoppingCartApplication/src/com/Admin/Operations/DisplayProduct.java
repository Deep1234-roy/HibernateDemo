package com.Admin.Operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.Admin.AdminMenu;

public class DisplayProduct {
	public DisplayProduct() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		System.out.println("The Products which are Added Latest by Admin are : -");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from AdminAddProduct");
		System.out.println("Product ID" + "     " + "Product Name" + "     " + "Price");
		while(rs.next()) {
			System.out.println("  " + rs.getInt(1) +"            " + rs.getString(2) + "            " + rs.getInt(3));
		}
		AdminMenu admenu = new AdminMenu();
		con.close();
	}
}
