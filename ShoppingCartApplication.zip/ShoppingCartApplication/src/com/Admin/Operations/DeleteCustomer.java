package com.Admin.Operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.Admin.AdminMenu;

public class DeleteCustomer {
	Scanner sc = new Scanner(System.in);
	public DeleteCustomer() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		System.out.print("How many Customers do you want to Delete? : ");
		int dltCust = sc.nextInt();
		for(int i=0;i<dltCust;i++) {
			System.out.print("Enter the Customer ID which you want to delete : ");
			int id = sc.nextInt();
			PreparedStatement pst = con.prepareStatement("delete from Customers where CustomerID=?");
			pst.setInt(1, id);
			pst.executeUpdate();
		}
		System.out.println("Customer Record Deleted Successfully!!!");
		AdminMenu admenu = new AdminMenu();
		con.close();
	}
}
