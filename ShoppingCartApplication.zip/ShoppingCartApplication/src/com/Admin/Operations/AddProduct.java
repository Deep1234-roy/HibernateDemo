package com.Admin.Operations;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.Admin.AdminMenu;

public class AddProduct {
	Scanner sc = new Scanner(System.in);
	public AddProduct() throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		FileWriter fwr = new FileWriter("C:\\Users\\Deepr\\Documents\\Deep\\ProductDetails.txt",true);
		System.out.print("How many Products Do you want to Add? : ");
		int no_of_prod = sc.nextInt();
		for(int i=0; i<no_of_prod; i++) {
			System.out.print("Enter the Product ID : ");
			int id = sc.nextInt();
			System.out.print("Enter the Product Name : ");
			String name = sc.next();
			System.out.print("Enter the Product Price : ");
			int price = sc.nextInt();
			PreparedStatement pst = con.prepareStatement("insert into AdminAddProduct values (?,?,?)");
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setInt(3, price);
			fwr.write(id + "     " + name + "     " + price + "\n");
			pst.executeUpdate();	
		}
		fwr.close();
		System.out.println("Products are Added Successfully!!!!!");
		AdminMenu admenu = new AdminMenu();
		con.close();
	}
}
