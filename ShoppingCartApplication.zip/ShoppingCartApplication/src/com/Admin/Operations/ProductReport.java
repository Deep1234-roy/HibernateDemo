package com.Admin.Operations;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.Admin.AdminMenu;

public class ProductReport {
	public void ProductReportGenerate() throws IOException, ClassNotFoundException, SQLException {
		File file = new File("C:\\Users\\Deepr\\Documents\\Deep\\ProductDetails.txt");
		//FileReader frdr = new FileReader(file);
		Scanner data = new Scanner(file);
		while(data.hasNextLine()) {
			String data1 = data.nextLine();
			System.out.println(data1);
		}
		AdminMenu admenu = new AdminMenu();
	}
}
