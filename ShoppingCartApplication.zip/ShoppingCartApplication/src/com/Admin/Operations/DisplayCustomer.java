package com.Admin.Operations;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Admin.AdminMenu;

public class DisplayCustomer {
	@SuppressWarnings("unchecked")
	public List DisplayCustomer() throws ClassNotFoundException, SQLException, IOException {
		List data = new ArrayList();
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		System.out.println("***************ALL CUSTOMER DETAILS*******************");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from Customers");
		System.out.println("Customer ID" + "   " + "Customer Name" + "           " + "Email" + "            " + "Phone No." + "      " + "Address");
		while(rs.next()) {
			System.out.println("  " + rs.getInt(1) + "            " + rs.getString(2) + "        " + rs.getString(3) + "         " + rs.getInt(4) + "       " + rs.getString(5));
			data.add("  " + rs.getInt(1) + "            " + rs.getString(2) + "        " + rs.getString(3) + "         " + rs.getInt(4) + "       " + rs.getString(5));
		}
		AdminMenu admenu = new AdminMenu();
		con.close();
		return data;
	}
}
