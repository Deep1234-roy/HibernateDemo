package com.Admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.Admin.Operations.AddProduct;
import com.Admin.Operations.CustomerReport;
import com.Admin.Operations.DeleteCustomer;
import com.Admin.Operations.DeleteProduct;
import com.Admin.Operations.DisplayCustomer;
import com.Admin.Operations.DisplayProduct;
import com.Admin.Operations.ProductReport;
import com.Admin.Operations.UpdateProduct;
import com.open.SecondMenu;

public class AdminMenu {
	Scanner sc = new Scanner(System.in);
	public AdminMenu() throws ClassNotFoundException, SQLException, IOException{
		System.out.println("*************ADMIN OPERATIONS*****************");
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCVBCP4-BLL\\SQLEXPRESS2019;databaseName=storeTables;user=sa;password=Password_123");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from AdminOperations");
		System.out.println("Sl.No." + "   " + "Admin Operations");
		while(rs.next()) {
			System.out.println(rs.getInt(1)  + "        " +  rs.getString(2));
		}
		System.out.println(0 + "        " + "Exit");
		System.out.println("-------------------------------------------------");
		System.out.print("Enter your Preferred Operation : ");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("*************ADD PRODUCT*************");
			AddProduct adp = new AddProduct();
			break;
		case 2:
			System.out.println("*************DISPLAY PRODUCT*************");
			DisplayProduct disP = new DisplayProduct();
			break;
		case 3:
			System.out.println("*************DELETE PRODUCT*************");
			DeleteProduct dltP = new DeleteProduct();
			break;
		case 4:
			System.out.println("*************UPDATE PRODUCT*************");
			UpdateProduct udP = new UpdateProduct();
			break;
		case 5:
			System.out.println("*************PRODUCT REPORT**************");
			ProductReport pr = new ProductReport();
			pr.ProductReportGenerate();
			break;
		case 6:
			System.out.println("*************DISPLAY CUSTOMER**************");
			DisplayCustomer dsp = new DisplayCustomer();
			dsp.DisplayCustomer();
			break;
		case 7:
			System.out.println("*************DELETE CUSTOMER**************");
			DeleteCustomer dcp = new DeleteCustomer();
			break;
		case 8:
			System.out.println("**************CUSTOMER REPORT****************");
			CustomerReport cstR = new CustomerReport();
			cstR.CustomerReportGenerate();
			break;
		case 0:
			System.out.println("Thanks for Closing the Admin Menu!!!!!!");
			SecondMenu obj = new SecondMenu();
			obj.SecondMenu();
			break;
		default:
			System.out.println("Please Choose Valid Operation from above Admin Menu!!!!");
			AdminMenu admenu = new AdminMenu();
		}
		con.close();
	}
}
