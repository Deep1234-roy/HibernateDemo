package com.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		Employee obj = new Employee();
		Configuration conf =new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		obj.setEmp_id(3);
		obj.setEmp_name("James");
		obj.setEmp_salary(7500.50f);
		System.out.println("Execution Done, Data Added in LogFile, please check");
		session.save(obj);
		trans.commit();

	}

}
