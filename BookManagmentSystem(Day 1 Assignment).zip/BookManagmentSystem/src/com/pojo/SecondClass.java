package com.pojo;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SecondClass {
	public SecondClass(){
		Scanner sc = new Scanner(System.in);
		BookInformation obj = new BookInformation();
		Configuration conf = new Configuration();
		conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		System.out.print("Enter Book ID : ");
		int book_id = sc.nextInt();
		System.out.print("Enter Book Name : ");
		String book_name = sc.next();
		System.out.print("Enter Book Author Name : ");
		String book_author = sc.next();
		System.out.print("Enter Book Price : ");
		double book_price = sc.nextDouble();
		obj.setBook_id(book_id);
		obj.setBook_name(book_name);
		obj.setBook_author(book_author);
		obj.setBook_price(book_price);
		System.out.println("Record Inserted!!....Please Check in Log4j File");
		session.save(obj);
		trans.commit();
	}
}
