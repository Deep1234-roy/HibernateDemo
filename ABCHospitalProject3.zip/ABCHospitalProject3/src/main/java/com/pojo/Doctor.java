package com.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="DoctorDetails")
public class Doctor {
	@Id
	private int doct_id;
	private String doct_name;
	private String doct_specialty;
	private String doct_address;
	private String doct_phonenumber;
	private String patie_list;
	@ManyToMany
	private Patient patient;


	public int getDoct_id() {
		return doct_id;
	}

	public void setDoct_id(int doct_id) {
		this.doct_id = doct_id;
	}

	public String getDoct_name() {
		return doct_name;
	}

	public void setDoct_name(String doct_name) {
		this.doct_name = doct_name;
	}

	public String getDoct_specialty() {
		return doct_specialty;
	}

	public void setDoct_specialty(String doct_specialty) {
		this.doct_specialty = doct_specialty;
	}

	public String getDoct_address() {
		return doct_address;
	}

	public void setDoct_address(String doct_address) {
		this.doct_address = doct_address;
	}

	public String getDoct_phonenumber() {
		return doct_phonenumber;
	}

	public void setDoct_phonenumber(String doct_phonenumber) {
		this.doct_phonenumber = doct_phonenumber;
	}

	public String getPatie_list() {
		return patie_list;
	}

	public void setPatie_list(String patie_list) {
		this.patie_list = patie_list;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

}
