package com.admin;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DeleteProduct {
	Scanner sc = new Scanner(System.in);
	public void deleteProducts() {
		//DisplayProducts obj = new DisplayProducts();
		ArrayList<String> list = new ArrayList<String>();
		list.add("Bottle");
		list.add("Pressure Cooker");
		list.add("Saree");
		//List list = obj.getList();
		System.out.print("How many Products do you want to delete ?");
		int dltProduct = sc.nextInt();
		for(int i=0; i<dltProduct; i++) {
			list.remove(i);
		}
		System.out.print("Now the List becomes :- " + list);
	}
	
}
