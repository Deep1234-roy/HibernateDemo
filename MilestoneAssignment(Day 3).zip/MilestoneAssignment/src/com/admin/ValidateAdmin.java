package com.admin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ValidateAdmin {
	public boolean validateAdmin() {
		boolean login=false;
		Scanner input=new Scanner(System.in);
		String [] credentials = {"Admin","Admin123"};
		List<String> credentialList = new ArrayList<>(Arrays.asList(credentials));
		System.out.print("Enter Admin Name:- ");
		String adName = input.next();
		System.out.print("Enter Admin Password:- ");
		String adPass = input.next();
		if(credentialList.contains(adName) && credentialList.contains(adPass)) {
			login=true;
		}else {
			System.out.println("Your Admin Name or Password is incorrect!!!!");
			login=false;
		}
		return login;
	}
}
