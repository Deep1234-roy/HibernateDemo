package com.admin;
import com.products.model.Customers;
import com.products.model.Products;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.citiustech.FirstMenu;
public class AdminMenu {
	Scanner sc = new Scanner(System.in);
	public void AdminMenu() {
		System.out.println("--------------Admin Operations----------------");
		System.out.println("     " + "SL.NO " + "      " + "Operations ");
		int [] SerialNo = new int[10];  //creating serial no array
		SerialNo[0]=1;
		SerialNo[1]=2;
		SerialNo[2]=3;
		SerialNo[3]=4;
		SerialNo[4]=5;
		SerialNo[5]=6;
		SerialNo[6]=7;
		SerialNo[7]=8;
		SerialNo[8]=9;
		SerialNo[9]=10;
		String [] OperationList = new String[10]; //creating Operations Array
		OperationList[0] = "Add Product";
		OperationList[1] = "Delete Product";
		OperationList[2] = "Display Product";
		OperationList[3] = "Update Report";
		OperationList[4] = "Update Report";
		OperationList[5] = "Generate Product Report";
		OperationList[6] = "Display Customer Details";
		OperationList[7] = "Delete Customer";
		OperationList[8] = "Generate Customer Report";
		OperationList[9] = "Exit";
		for(int item=0;item<OperationList.length;item++) {
			System.out.println("      " + SerialNo[item] + "          " + OperationList[item]);
		}
		System.out.print("Please select your Operation:- ");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			AddProduct obj = new AddProduct();
			//obj.AddProducts();
			break;
		case 2:
			//System.out.println("Delete Product Segment");
			DeleteProduct dlt = new DeleteProduct();
			dlt.deleteProducts();
			break;
		case 3:
//			DisplayProducts obj1 = new DisplayProducts();
//			obj1.getList();
			AddProduct obj1 = new AddProduct();
			List list= obj1.getProducts();
			System.out.println("--------------Display Products------------------");
			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Products object = (Products) iterator.next();
			System.out.println("             " + object.getProd_id()+"       "+
			object.getProd_name());
			}
			AdminMenu();
			break;
		case 4:
			System.out.println("Get Report Segment");
			break;
		case 7:
			DisplayCustomers customer = new DisplayCustomers();
			List lst = customer.getCustomers();
			System.out.println("------------------Display Customer Details------------------");
			for (Iterator iterator = lst.iterator(); iterator.hasNext();) {
				Customers object = (Customers) iterator.next();
				System.out.println("      " + object.getCust_id()+"      "+
				object.getCust_name() + "      " + object.getCust_address() + "      " + object.getCust_phone());
				}
				AdminMenu();
				break;
			
		case 10:
			System.out.println("You have successfully logged out!!!!");
			FirstMenu obj2 = new FirstMenu();
			obj2.MenuFirst();
			break;
		default:
			System.out.println("Please select valid Operations!!!");
			AdminMenu();
		}
	}
}
