package com.admin;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.products.model.Products;

public class AddProduct {
	public String choice;
	Scanner input = new Scanner(System.in);
	//Products obj1;
	public List getProducts() {
		ArrayList<Products> list = new ArrayList<Products>();
		//list.add(obj1);

		Products product1 = new Products(1,"Shirt");
		Products product2 = new Products(2,"Mobiles");
		//Product product2 = new Product(2,"IPhone13");
		list.add(product1);
		list.add(product2);

		return list;
		}
	
	
	
//	public void AddProducts(){
//		//String prod_name=null;
//		ArrayList<Products> list = new ArrayList<Products>();
////		System.out.print("How many Products Do you want to Add ? ");
////		int noOfProducts = input.nextInt();
////		for(int i=0; i<noOfProducts;i++) {
////			System.out.println("Enter the ID of Products");
////			int prod_id=input.nextInt();
////			System.out.println("Enter the Name of Products");
////			String prod_name=input.next();
////			System.out.print("Enter the Product : ");
////			prod_name = input.next();
////			list.add(prod_name);
//			Products prod1 = new Products(1,"Mobiles");
//			Products prod2 = new Products(2,"Dinner Set");
//			//obj1=obj;
//			list.add(prod1);
//			list.add(prod2);
//		}
////		System.out.println("The Products which are added :- " + list);
////		System.out.print("Do you want to Add more ? ");
////		choice = input.next();
////		if(choice.equals("Yes")) {
////			//AddProducts();
////			System.out.print("Enter the name of Product which you want to add : - ");
////			prod_name = input.next();
////			list.add(prod_name);
////			System.out.println("The Products which are added :- " + list);
////			AdminMenu obj = new AdminMenu();
////			obj.AdminMenu();
////		}else if(choice.equals("No")) {
////			AdminMenu obj = new AdminMenu();
////			obj.AdminMenu();
////		}
//		AdminMenu obj = new AdminMenu();
//		obj.AdminMenu();
//	}
	
	
}
