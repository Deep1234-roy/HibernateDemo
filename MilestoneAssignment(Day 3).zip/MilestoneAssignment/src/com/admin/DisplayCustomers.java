package com.admin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.products.model.Customers;

public class DisplayCustomers {
	public String choice;
	Scanner sc = new Scanner(System.in);
	public List getCustomers() {
		ArrayList<Customers> list = new ArrayList<Customers>();
		Customers cust1 = new Customers(1,"Deep","Bengal",7980025126l);
		Customers cust2 = new Customers(2,"Ayan","Pune",877465382l);
		Customers cust3 = new Customers(3,"Shalini","Channai",8373829273l);
		list.add(cust1);
		list.add(cust2);
		list.add(cust3);
		return list;
	}
}	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//AddProduct obj = new AddProduct();
//		List li = obj.AddProducts();
//		Iterator itr = li.iterator();
//		if(itr.hasNext()) {
//			System.out.print(itr.next());
//		}else {
//			System.out.println("List is empty!!");
//		}
//		ArrayList<String> list = new ArrayList<String>();
//		list.add("Bottle");
//		list.add("Pressure Cooker");
//		list.add("Saree");
//		Iterator itr = list.iterator();
//		System.out.println("The Products are :- ");
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
//		System.out.print("Want to Display again ? ");
//		choice = sc.next();
//		if(choice.equals("Yes")) {
//			getList();
//		}else if(choice.equals("No")) {
//			AdminMenu obj = new AdminMenu();
//			obj.AdminMenu();
//		}
//		return list;
		
	
