package com.citiustech;

public class Main {

	public static void main(String[] args) {
		FirstMenu obj = new FirstMenu();
		obj.MenuFirst();
	}
}
