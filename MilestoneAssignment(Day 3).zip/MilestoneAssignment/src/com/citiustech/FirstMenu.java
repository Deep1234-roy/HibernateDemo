package com.citiustech;

import java.util.Scanner;

import com.admin.AdminMenu;
import com.admin.ValidateAdmin;

public class FirstMenu {
	Scanner inp = new Scanner(System.in);
	public void MenuFirst() {
		System.out.println("--------------Role---------------");
		System.out.println("     " + "SL.NO " + "      " + "Role ");
		int [] SerialNo = new int[3];  //creating serial no array
		SerialNo[0]=1;
		SerialNo[1]=2;
		SerialNo[2]=0;
		String [] MenuList = new String[3]; //creating Menu Array
		MenuList[0] = "Admin";
		MenuList[1] = "Customer";
		MenuList[2] = "Exit";
		for(int item=0;item<MenuList.length;item++) {
			System.out.println("      " + SerialNo[item] + "          " + MenuList[item]);
		}
		System.out.print("Please Select your Role :- ");
		int roleSelect = inp.nextInt();
		if(roleSelect == 1) {
			System.out.println("You have selected your role as an Admin!!!!");
			ValidateAdmin validationAdmin = new ValidateAdmin();
			if(validationAdmin.validateAdmin() == true) {
				System.out.println("You have successfully Logged in as an Admin!!");
				AdminMenu obj = new AdminMenu();
				obj.AdminMenu();
			}else {
				System.out.println("You are not an Valid Admin!!");
			}
		}else if(roleSelect == 2) {
			System.out.println("You have selected your role as a Customer!!!!");
			ValidateUser obj1 = new ValidateUser();
			if(obj1.validateUser() == true) {
				MainMenu obj2 = new MainMenu();
			}else {
				System.out.println("You are not an Authorized User!!");
			}
		}else if(roleSelect == 0) {
			System.out.println("Thanks for closing our application!!");
			System.exit(0);
		}else {
			System.out.println("Please Select valid Role from Menu!!");
			MenuFirst();
		}
	}
	
}
