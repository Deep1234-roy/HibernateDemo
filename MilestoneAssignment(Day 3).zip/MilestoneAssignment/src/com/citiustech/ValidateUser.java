package com.citiustech;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class ValidateUser {
	
	public boolean validateUser() {
		boolean login=false;
		Scanner input=new Scanner(System.in);
		String [] credentials = {"Deep","Deep1234"};
		List<String> credentialList = new ArrayList<>(Arrays.asList(credentials));
		System.out.print("Enter User Name:- ");
		String uName = input.next();
		System.out.print("Enter User Password:- ");
		String uPass = input.next();
		if(credentialList.contains(uName) && credentialList.contains(uPass)) {
			System.out.println("-----------Welcome to Our Site--------------");
			login=true;
		}else {
			System.out.println("Your Username or Password is incorrect!!!!");
			login=false;
		}
		return login;
	}
}
