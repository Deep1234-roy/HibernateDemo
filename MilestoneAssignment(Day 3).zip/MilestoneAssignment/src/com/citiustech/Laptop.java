package com.citiustech;

import java.util.Scanner;

public class Laptop {
	Scanner input = new Scanner(System.in);
	int product;
	Laptop(){
		System.out.println("---------------Laptop----------------");
		System.out.println("  SL.NO.     Brand Name      Price ");
		int [] SerialNo = new int[3];  //creating serial no array
		SerialNo[0]=1;
		SerialNo[1]=2;
		SerialNo[2]=3;
		String [] Laptops = new String[3];   //creating Laptop array
		int [] Prices = new int[3];          //creating Price array
		Prices[0]=50000;
		Prices[1]=70000;
		Prices[2]=40000;
		Laptops[0] = "Dell";
		Laptops[1] = "Acer";
		Laptops[2] = "Asus";
		for(int i=0; i<Laptops.length; i++) {
			System.out.println("    " + SerialNo[i] + "        " + Laptops[i] + "            " + Prices[i]);
		}
		System.out.println("    0.       Exit");
		System.out.println("------------------------------------");
		System.out.print("Please select Product : ");
		product = input.nextInt();
		switch(product) {
		case 1:
			System.out.println("You have selected:- Dell Laptop");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 2:
			System.out.println("You have selected:- Acer Laptop");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 3:
			System.out.println("You have selected:- Asus Laptop");
			System.out.println(calculateBill());
			pageTrack();
			break;
		case 0:
			System.out.println("Thanks for closing the Laptop Menu!!");
			MainMenu obj = new MainMenu();
			break;
		default:
			System.out.println("Please choose Valid Products from Menu!!");
			Mobile obj5 = new Mobile();
		}
	}

	int calculateBill() {
		System.out.print("Please Enter the Quantity : ");
		int quant = input.nextInt();
		int price=0;
		if(product == 1) {
			price=50000;
		}else if(product == 2) {
			price=70000;
		}else if(product==3) {
			price=40000;
		}
		System.out.print("Total Bill is : ");
		return (quant * price);
	}
	void pageTrack() {
		System.out.print("Do You Wish to Continue? ");
		String choice = input.next();
		if(choice.equals("Yes")) {
			System.out.println("Thanks for once again showing your interest!!");
			Laptop obj = new Laptop();
		}else {
			System.out.println("Thanks for closing the Laptop Menu!!");
			MainMenu obj = new MainMenu();
		}
	}
}
