package com.dao;

import org.hibernate.cfg.Configuration;

public class ConfigureDao {
	public static Configuration getCustomConfig() {
		Configuration conf = new Configuration();
		conf.configure("hibernate.cfg.xml");
		return conf;
	}
}
