package com.controller;

import com.dao.ConfigureDao;
import com.menu.AdminMainMenu;
import com.pojo.Doctor;
import com.pojo.Patient;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
public class DoctorController {
static Configuration conf = ConfigureDao.getCustomConfig();
	

	//ADD DOCTOR
	public static void addDoctor() {
	    SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		System.out.print("Enter the Doctor ID : - ");
		int doc_id = input.nextInt();
		System.out.print("Enter the Name of Doctor : - ");
		String doc_name = input.next();
		System.out.print("Enter the Speciality of Doctor : - ");
		String doc_spl = input.next();
		System.out.print("Enter the Doctor Adress : - ");
		String doc_add = input.next();
		System.out.print("Enter the Phone number of Doctor : - ");
		long doc_phone = input.nextLong();
		System.out.print("Enter Assigned Patient File Number : - ");
		int pat_id = input.nextInt();
		Doctor doc = new Doctor(); 
		doc.setDoctor_ID(doc_id);
		doc.setDoctor_Name(doc_name);
		doc.setDoctor_specialty(doc_spl);
		doc.setDoctor_Address(doc_add);
		doc.setDoctor_Phone_number(doc_phone);
	
	    Patient pat = new Patient();
	    pat.setPatient_File_number(pat_id);
		pat.setDoctor(doc);
		doc.setPatient(pat);
		
		session.save(doc);
		session.save(pat);
		tran.commit();
		session.close();
		System.out.println("Doctor Details Added Successfully");
		System.out.print("Do You Wish to Add More Doctor Records ? ");
		String ch = input.next();
		if(ch.equalsIgnoreCase("yes")) {
			addDoctor();
		}else {
			System.out.println("Thanks for Adding the Doctor Details!!!");
			AdminMainMenu csm = new AdminMainMenu();
		}
		System.out.println("Doctor Records Added Successfully");
	}

	//Update Doctor Details
	public static void updateDoctor() {
		Configuration conf = new Configuration();
	    conf.configure();
	    SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("update Doctor set Doctor_Name=:n where Doctor_ID=:i");
		System.out.print("Enter the Doctor ID of the Doctor : - ");
		int doc_id = input.nextInt();
		System.out.println("Enter the New Name of Doctor : - ");
		String doc_name = input.next();
		qr.setParameter("n", doc_name);
		qr.setParameter("i", doc_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		tran.commit();
		System.out.println("Doctor Details has been Updated Successfully!!!");
		session.close();
	}

	//Delete Doctor Details
	public static void deleteDoctor() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		Query qr = session.createQuery("delete from Doctor where Doctor_ID=:i");
		System.out.print("Enter the Doctor Id of Doctor : - ");
		int doc_id = input.nextInt();
		qr.setParameter("i", doc_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		tran.commit();
		System.out.println("Doctor Details has been deleted successfully!!!");
		session.close();
	}

	//Display Specific Doctor Details
	public static void ViewOneDoctor() {
		Configuration conf = new Configuration();
	    conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Patient pat = new Patient();
		TypedQuery qr = session.createQuery("from Doctor where Doctor_ID=:i"); 
		System.out.print("Enter the Doctor ID of Doctor : - ");
		int doc_id = input.nextInt();
		qr.setParameter("i", doc_id);
		List<Doctor> doc = qr.getResultList();
		Iterator<Doctor> itr = doc.iterator();
		while(itr.hasNext()) {
			Doctor doct = itr.next();
			System.out.println("Doctor_ID = "+doct.getDoctor_ID()
			+" Doctor_Name = "+doct.getDoctor_Name()+" Doctor's_Speciality = "+doct.getDoctor_specialty()
			+"Doctor_Address = "+doct.getDoctor_Address()
			+"Doctor_Phone_number = "+doct.getDoctor_Phone_number());
		
		}
	}
	
	//Display all Doctor Information
	public static void getDoctor() {
		Configuration conf = new Configuration();
	    conf.configure();
	    Scanner input = new Scanner(System.in);
	    Patient pat = new Patient();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		TypedQuery qr = session.createQuery("from Doctor"); 
		List<Doctor> doc = qr.getResultList();
		Iterator<Doctor> itr = doc.iterator();
		while(itr.hasNext()) {
			Doctor doct = itr.next();
			System.out.println("Doctor_ID = "+doct.getDoctor_ID()
			+" Doctor_Name = "+doct.getDoctor_Name()+" Doctor's_Speciality = "+doct.getDoctor_specialty()
			+"Doctor_Address = "+doct.getDoctor_Address());
			
		}
		
	}

}
