package com.pojo;

//import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="PatientDetails")
public class Patient {	
	@Id
	@Column(name="Patient_File_number")
	private int Patient_File_number;
	private String Patient_Name;
	private String Patient_problem;
	private int Patient_age;
	private String Patient_Address;
	private long Patient_Phone_number;
	@OneToOne
	private Doctor doctor;
	
	public int getPatient_File_number() {
		return Patient_File_number;
	}
	public void setPatient_File_number(int patient_File_number) {
		Patient_File_number = patient_File_number;
	}
	public String getPatient_Name() {
		return Patient_Name;
	}
	public void setPatient_Name(String patient_Name) {
		Patient_Name = patient_Name;
	}
	public String getPatient_problem() {
		return Patient_problem;
	}
	public void setPatient_problem(String patient_problem) {
		Patient_problem = patient_problem;
	}
	public int getPatient_age() {
		return Patient_age;
	}
	public void setPatient_age(int patient_age) {
		Patient_age = patient_age;
	}
	public String getPatient_Address() {
		return Patient_Address;
	}
	public void setPatient_Address(String patient_Address) {
		Patient_Address = patient_Address;
	}
	public long getPatient_Phone_number() {
		return Patient_Phone_number;
	}
	public void setPatient_Phone_number(long patient_Phone_number) {
		Patient_Phone_number = patient_Phone_number;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	
	
}
