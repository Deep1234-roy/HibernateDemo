package com.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="DoctorDetails")
public class Doctor {
	@Id
	//@Column(name="Doctor_ID")
	private int	Doctor_ID;
	private String Doctor_Name;
	private String Doctor_specialty;
	private String Doctor_Address;
	private long Doctor_Phone_number;
	@OneToOne
	private Patient patient;
	
	public int getDoctor_ID() {
		return Doctor_ID;
	}
	public void setDoctor_ID(int doctor_ID) {
		Doctor_ID = doctor_ID;
	}
	public String getDoctor_Name() {
		return Doctor_Name;
	}
	public void setDoctor_Name(String doctor_Name) {
		Doctor_Name = doctor_Name;
	}
	public String getDoctor_specialty() {
		return Doctor_specialty;
	}
	public void setDoctor_specialty(String doctor_specialty) {
		Doctor_specialty = doctor_specialty;
	}
	public String getDoctor_Address() {
		return Doctor_Address;
	}
	public void setDoctor_Address(String doctor_Address) {
		Doctor_Address = doctor_Address;
	}
	public long getDoctor_Phone_number() {
		return Doctor_Phone_number;
	}
	public void setDoctor_Phone_number(long doctor_Phone_number) {
		Doctor_Phone_number = doctor_Phone_number;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	
	
	
	
}
