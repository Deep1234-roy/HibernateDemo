package com.menu;

import java.util.Scanner;

import com.controller.PatientController;

public class PatientMenu {
	PatientMenu()
	{
		PatientController ptc = new PatientController();
		Scanner sc = new Scanner(System.in);
		System.out.println("---------------Patient Menu---------------");
		System.out.println("1. Add Patient details \n"+
				"2. Update Patient details \n" +
				"3. Delete Patient details \n" +
				"4. View all Patient details \n" +
				"5. View single Patient details by Patient File number \n" +
				"0. Exit\n");
		System.out.print("Please Enter your Operation : - ");
		int choice = sc.nextInt();
		switch(choice)
		{
			case 1:
				// ADD Patient Details
				System.out.println("*********PATIENT ADD OPERATION*********");
				ptc.addPatient();
				break;
			case 2:
				// UPDATE Patient Details
				System.out.println("*********PATIENT UPDATE OPERATION*********");
				ptc.updatePatient();
				break;
			case 3:
				// DELETE Patient Details
				System.out.println("*********PATIENT DELETE OPERATION*********");
				ptc.deletePatient();
				break;
			case 4:
				//VIEW ALL PATIENT RECORDS
				System.out.println("*********PATIENT DISPLAY OPERATION*********");
				ptc.AllPatient();
				break;
			case 5:
				//VIEW ONE SPECIFIC PATIENT DETAILS
				System.out.println("*********SPECIFIC PATIENT DISPLAY OPERATION*********");
				ptc.ViewOnePatient();
				break;
			case 0:
				System.out.println("Thanks for Closing the Doctor Menu!!!");
				AdminMainMenu adm = new AdminMainMenu();
				break;
			default:
				System.out.println("Please Select Valid Operation from Menu!!");
		}
	}
}
