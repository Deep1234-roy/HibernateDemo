package com.menu;

import java.util.Scanner;

import com.controller.DoctorController;

public class DoctorMenu {
	DoctorMenu()
	{
		DoctorController dcm = new DoctorController();
		Scanner sc = new Scanner(System.in);
		System.out.println("-------------------Doctor Menu-------------------");
		System.out.println("1. Add Doctor details \n"+
				"2. Update Doctor details \n" +
				"3. Delete Doctor details \n" +
				"4. View all Doctor details \n" +
				"5. View single Doctor details by Doctor ID \n" +
				"0. EXIT \n");
		System.out.print("Please Enter your Operation : ");
		int choice = sc.nextInt();
		switch(choice)
		{
			case 1:
				// ADD ALL DOCTORS
				System.out.println("****************DOCTOR ADD OPERATION****************");
				dcm.addDoctor();
				break;
			case 2:
				// UPDATE DOCTOR DETAILS
				System.out.println("****************DOCTOR UPDATE OPERATION****************");
				dcm.updateDoctor();
				break;
			case 3:
				// DELETE DOCTOR DETAILS
				System.out.println("****************DOCTOR DELETE OPERATION****************");
				dcm.deleteDoctor();
				break;
			case 4:
				//VIEW ALL DOCTORS
				System.out.println("****************DOCTOR DISPLAY OPERATION****************");
				dcm.getDoctor();
				break;
			case 5:
				//VIEW ONE SPECIFIC DOCTOR DETAILS BY IT'S ID
				System.out.println("****************SPECIFIC DOCTOR DISPLAY OPERATION****************");
				dcm.ViewOneDoctor();
				break;
			case 0:
				System.out.println("Thanks for Closing the Doctor Menu!!!");
				AdminMainMenu adm = new AdminMainMenu();
				break;
			default:
				System.out.println("Please Select Valid Operation from Menu!!");
		}
	}

}
