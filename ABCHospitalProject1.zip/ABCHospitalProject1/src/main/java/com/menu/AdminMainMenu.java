package com.menu;

import java.util.Scanner;


public class AdminMainMenu {
	public AdminMainMenu() {
		Scanner sc = new Scanner(System.in);
        System.out.println( "****************Admin Menu****************");
        System.out.println("1.Doctor     \n2.Patient     \n0.Exit");
		System.out.print("Enter Your Operation : - ");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("You selected for Doctor Operation!!!");
			DoctorMenu dcm = new DoctorMenu();
			break;
		case 2:
			System.out.println("You selected for Patient Operation!!!");
			PatientMenu ptn = new PatientMenu();
			break;
		case 0:
			System.out.println("Thanks for Closing our Application!!!");
			System.exit(0);
			break;
		default:
			System.out.println("Please choose Appropriate Options!!!");
			AdminMainMenu adm = new AdminMainMenu();
		}
	}
}
