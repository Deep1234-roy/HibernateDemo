package com.menu;

import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		System.out.println("***********ABC HOSPITAL MANAGEMENT************");
		AdminMainMenu adm = new AdminMainMenu();
	}
}
