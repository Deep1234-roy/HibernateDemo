package com.pojo;

import java.util.Scanner;

public class DoctorMenu {
	DoctorMenu()
	{
		DoctorController dc = new DoctorController();
		Scanner sc = new Scanner(System.in);
		System.out.println("-----Doctor Menu------");
		System.out.println("1. Add Doctor details \n"+
				"2. Update Doctor details \n" +
				"3. Delete Doctor details \n" +
				"4. View all Doctor details \n" +
				"5. View single Doctor details by Doctor ID \n");
		System.out.println("enter your choice : ");
		int choice = sc.nextInt();
		switch(choice)
		{
			case 1:
				// ADD
				dc.addDoctor();
				break;
			case 2:
				// UPDATE
				dc.updateDoctor();
				break;
			case 3:
				// DELETE
				dc.deleteDoctor();
				break;
			case 4:
				//VIEW ALL
				dc.getDoctor();
				break;
			case 5:
				//VIEW ONE
				dc.ViewOneDoctor();
				break;
			default:
				System.out.println("Invalid choice");
		}
	}

}
