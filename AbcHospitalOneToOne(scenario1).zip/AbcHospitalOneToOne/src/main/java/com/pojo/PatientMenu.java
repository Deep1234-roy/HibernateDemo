package com.pojo;

import java.util.Scanner;

public class PatientMenu {
	PatientMenu()
	{
		PatientController pc = new PatientController();
		Scanner sc = new Scanner(System.in);
		System.out.println("-----Patient Menu------");
		System.out.println("1. Add Patient details \n"+
				"2. Update Patient details \n" +
				"3. Delete Patient details \n" +
				"4. View all Patient details \n" +
				"5. View single Patient details by Patient File number \n");
		System.out.println("enter your choice : ");
		int choice = sc.nextInt();
		switch(choice)
		{
			case 1:
				// ADD
				pc.addPatient();
				break;
			case 2:
				// UPDATE
				pc.updatePatient();
				break;
			case 3:
				// DELETE
				pc.deletePatient();
				break;
			case 4:
				//VIEW ALL
				pc.AllPatient();
				break;
			case 5:
				//VIEW ONE
				pc.ViewOnePatient();
				break;
			default:
				System.out.println("Invalid choice");
		}
	}

}
