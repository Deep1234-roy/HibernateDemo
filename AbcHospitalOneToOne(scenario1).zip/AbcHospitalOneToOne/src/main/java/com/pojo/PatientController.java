package com.pojo;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.dao.HospitalDao;

public class PatientController {

	
	
	static Configuration conf = HospitalDao.getCustomConfig();
	
	public static void addPatient() {

	    SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Patient_File_number :");
		int pt_id = input.nextInt();
		System.out.println("Enter the Name of Patient :");
		String pt_name = input.next();
		System.out.println("Enter the problem of Patient :");
		String pt_prob = input.next();
		System.out.println("Enter the age of Patient :");
		int pt_age = input.nextInt();
		System.out.println("Enter the Address of Patient :");
		String pt_address = input.next();
		System.out.println("Enter the phone number of Patient :");
		int pt_phone = input.nextInt();
		System.out.println("Enter assigned doctor id :");
		int doc_id = input.nextInt();
		Patient pat = new Patient();
		pat.setPatient_File_number(pt_id);
		pat.setPatient_Name(pt_name);
		pat.setPatient_problem(pt_prob);
		pat.setPatient_age(pt_age);
		pat.setPatient_Address(pt_address);
		pat.setPatient_Phone_number(pt_phone);
		
		Doctor doc = new Doctor();
		doc.setDoctor_ID(doc_id);
		
		pat.setDoctor(doc);
		doc.setPatient(pat);
		
		session.save(pat);
		session.save(doc);
		tran.commit();
		session.close();
		System.out.println("Patient Added Successfully");
	}

	public static void updatePatient() {

	    SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		Query qr = session.createQuery("update Patient set Patient_Name=:n where Patient_File_number=:i");
		System.out.println("Enter the Patient_File_number ");
		int Patient_File_number = input.nextInt();
		System.out.println("Enter the Name of Patient");
		String Patient_Name = input.next();
		qr.setParameter("n", Patient_Name);
		qr.setParameter("i", Patient_File_number);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Updated");
		tran.commit();
		session.close();
	}

	public static void deletePatient() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		
		Query qr = session.createQuery("delete from Patient where Patient_File_number=:i");
		System.out.println("Enter the Patient_File_number ");
		int pt_id = input.nextInt();
		qr.setParameter("i", pt_id);
		int row = qr.executeUpdate();
		System.out.println(row + " Rows Deleted");
		tran.commit();
		//session.close();
	}

	public static void ViewOnePatient() {
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Scanner input = new Scanner(System.in);
		Transaction tran = session.beginTransaction();
		TypedQuery qr = session.createQuery("from Patient where Patient_File_number=:i"); 
		System.out.println("Enter the Patient_File_number of Customer");
		int pt_id = input.nextInt();
		qr.setParameter("i", pt_id);
		List<Patient> pat = qr.getResultList();
		Iterator<Patient> itr = pat.iterator();
		while(itr.hasNext()) {
			Patient pnt = itr.next();
			System.out.println("Patient_File_number = "+pnt.getPatient_File_number()
			+" Patient_Name = "+pnt.getPatient_Name()+" Patient_Problem = "+pnt.getPatient_problem()+
			"Patient_Age = "+pnt.getPatient_age()+"Patient_Address = "+pnt.getPatient_Address()
			+"Patient_Phone_number = "+pnt.getPatient_Phone_number());
		}
		tran.commit();
		session.close();
	}
	
	public static void AllPatient() {
		Configuration conf = new Configuration();
	    conf.configure();
		SessionFactory sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.beginTransaction();
		TypedQuery qr = session.createQuery("from Patient"); 
		List<Patient> pat = qr.getResultList();
		Iterator<Patient> itr = pat.iterator();
		while(itr.hasNext()) {
			Patient pnt = itr.next();
			System.out.println("Patient_File_number = "+pnt.getPatient_File_number()
			+" Patient_Name = "+pnt.getPatient_Name()+" Patient_Problem = "+pnt.getPatient_problem()+
			"Patient_Age = "+pnt.getPatient_age()+"Patient_Address = "+pnt.getPatient_Address()
			+"Patient_Phone_number = "+pnt.getPatient_Phone_number());

		}
		tran.commit();
		session.close();
	}
}
