package com.pojo;

import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
        System.out.println( "-------Admin Menu------");
        System.out.println("1.Patient Menu \n" + "2.Doctor Menu ");
        System.out.print("select your choice : ");
        int choice = sc.nextInt();
        if(choice==1)
        {
        	//patient menu
        	PatientMenu pm = new PatientMenu();
        }
        if(choice==2)
        {
        	//doctor menu
        	DoctorMenu dm = new DoctorMenu();
        }
    }
}
